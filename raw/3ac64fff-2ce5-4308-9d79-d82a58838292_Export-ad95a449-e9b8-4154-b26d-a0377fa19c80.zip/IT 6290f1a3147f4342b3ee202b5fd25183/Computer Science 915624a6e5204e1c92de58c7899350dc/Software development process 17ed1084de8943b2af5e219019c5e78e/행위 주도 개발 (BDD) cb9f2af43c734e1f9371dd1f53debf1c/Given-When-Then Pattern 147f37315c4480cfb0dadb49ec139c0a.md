# Given-When-Then Pattern

**Given**

- 시나리오 진행에 주어진 상태.

**When**

- 시나리오 진행에 주어진 조건.

**Then**

- 시나리오 진행 완료 후 상태.