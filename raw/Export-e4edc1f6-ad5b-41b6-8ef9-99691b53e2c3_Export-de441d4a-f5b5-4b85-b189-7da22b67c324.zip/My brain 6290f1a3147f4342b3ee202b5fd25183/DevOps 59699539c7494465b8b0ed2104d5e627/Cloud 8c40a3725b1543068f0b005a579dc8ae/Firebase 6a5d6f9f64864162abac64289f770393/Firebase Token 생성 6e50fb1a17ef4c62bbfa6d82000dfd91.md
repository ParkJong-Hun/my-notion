# Firebase Token 생성

[Firebase CLI リファレンス  |  Firebase ドキュメント](https://firebase.google.com/docs/cli?hl=ja#cli-ci-systems)

1. `curl -sL https://firebase.tools | bash` 으로 Firebase CLI 인스톨
2. `firebase login:ci` 으로 로그인 액세스 개시
3. 터미널에 토큰이 출력됨.