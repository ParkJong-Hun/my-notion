# Compute Engine

<aside>
💡 Google의 데이터 센터에서 실행되는 가상 머신.

</aside>