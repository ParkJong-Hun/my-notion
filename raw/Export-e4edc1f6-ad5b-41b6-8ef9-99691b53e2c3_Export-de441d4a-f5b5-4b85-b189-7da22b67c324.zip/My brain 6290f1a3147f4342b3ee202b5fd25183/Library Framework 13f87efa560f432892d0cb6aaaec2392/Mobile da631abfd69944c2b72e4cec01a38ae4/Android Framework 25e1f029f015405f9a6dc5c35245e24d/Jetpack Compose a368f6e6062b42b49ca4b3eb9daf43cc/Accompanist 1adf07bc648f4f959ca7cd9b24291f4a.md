# Accompanist

<aside>
💡 Jetpack Compose를 위한 고품질 라이브러리 집합.

</aside>

Jetpack Compose에서 구현되지 않은 기능이나 성능 최적화를 위한 기능들을 제공.

Jetpack Compose의 확장으로 구현되기 떄문에 Jetpack Compose의 코드와 함께 사용 가능.