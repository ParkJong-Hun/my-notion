# Finite State Machine

<aside>
💡

유한 상태 기계.

상태와 전이만이 존재.

매우 높은 안전성을 보장.

규모가 커지면 복잡도가 매우 높아짐.

</aside>