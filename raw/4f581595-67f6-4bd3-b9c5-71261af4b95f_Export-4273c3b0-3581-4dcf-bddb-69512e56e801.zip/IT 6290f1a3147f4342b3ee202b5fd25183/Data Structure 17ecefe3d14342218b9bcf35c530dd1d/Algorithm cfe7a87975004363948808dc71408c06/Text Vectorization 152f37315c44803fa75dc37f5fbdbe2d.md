# Text Vectorization

<aside>
💡

텍스트 벡터화.
TF-IDF나 단어 임베딩을 통해 텍스트를 벡터 형태로 변환.

</aside>

[TF-IDF](Text%20Vectorization%20152f37315c44803fa75dc37f5fbdbe2d/TF-IDF%20152f37315c44806d80aacf308b0b96f3.md)

[Work Embedding](Text%20Vectorization%20152f37315c44803fa75dc37f5fbdbe2d/Work%20Embedding%20152f37315c4480439bd9dca615f4a723.md)