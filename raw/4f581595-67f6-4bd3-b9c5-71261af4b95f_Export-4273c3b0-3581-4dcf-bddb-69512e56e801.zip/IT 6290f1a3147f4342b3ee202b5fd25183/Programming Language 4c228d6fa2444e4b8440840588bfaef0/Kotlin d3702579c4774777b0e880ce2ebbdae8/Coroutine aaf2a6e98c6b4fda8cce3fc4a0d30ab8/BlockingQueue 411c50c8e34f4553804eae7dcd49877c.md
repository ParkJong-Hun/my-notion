# BlockingQueue

<aside>
💡 특정 상황에 쓰레드를 대기시키는 큐.
Channel과 다르게 close할 수 없고 이전에 넣은 값을 받을 수 없음.

</aside>