# Euclidean Distance

<aside>
💡

유클리드 거리.
두 점(데이터 포인트)  간 직선 거리를 계산해 유사성 측정.
클러스터링에 주로 사용.

</aside>