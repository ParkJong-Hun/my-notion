# Sementic Versioning

- example

# 4.2.1

<aside>
💡 **Major** . *Minor* . patch

</aside>

**Major Version**

기존 API가 변경 혹은 삭제 되었기 때문에 업데이트하면 동작하지 않을 수 있다는 경고의 의미

**Minor Version**

이전 버전과 호환되는 방식으로 API가 추가되었으니 살펴보라는 의미

**Patch Version**

이전 버전과 호환되는 버그 수정을 했다는 의미

<aside>
💡 Patch Version은 revision 버전과 build 버전으로 나뉠 수 있음.

</aside>