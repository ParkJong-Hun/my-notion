# LLVM

<aside>
💡 Low Level Virtual Machine.
프로그램을 컴파일 타임, 링크 타임, 런타임 상황에서 프로그램의 작성 언어에 상관없이 여러 언어를 변환할 수 있게 설계된 오픈 소스 컴파일러.
IR(중간 표현)이 핵심으로, 어셈블리어와 비슷한 저급 프로그래밍 언어.
Virtual Machine이라고 되어 있지만, 현재는 거의 관계가 없음.

</aside>