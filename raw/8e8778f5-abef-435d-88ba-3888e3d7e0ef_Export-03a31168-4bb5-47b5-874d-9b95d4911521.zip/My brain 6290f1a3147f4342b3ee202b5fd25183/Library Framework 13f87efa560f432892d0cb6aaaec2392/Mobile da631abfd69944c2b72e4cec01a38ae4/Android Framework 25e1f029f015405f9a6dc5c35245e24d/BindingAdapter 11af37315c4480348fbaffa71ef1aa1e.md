# BindingAdapter

### InverseBindingAdapter

양방향 데이터 바인딩 지원.

**attribute**

View의 특정 속성 정의.

**event**

속성이 변경될 때 발생하는 이벤트.

해당 이벤트 이름과 동일한 BindingAdapter를 정의해, setEventListener를 만들 수 있음.