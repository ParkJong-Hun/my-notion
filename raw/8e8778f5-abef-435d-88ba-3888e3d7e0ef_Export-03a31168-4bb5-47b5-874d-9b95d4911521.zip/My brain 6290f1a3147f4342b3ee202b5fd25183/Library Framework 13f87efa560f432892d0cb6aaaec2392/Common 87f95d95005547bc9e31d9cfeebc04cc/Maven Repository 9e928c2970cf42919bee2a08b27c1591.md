# Maven Repository

<aside>
💡 메이븐 프로젝트에서 종속성을 관리하는 데 사용되는 저장소.
로컬 저장소, 중앙 저장소, 원격 저장소로 나뉨.

</aside>

**Local Repository**

- 개발자의 PC에 설치된 저장소.
- .m2/repository에 위치.

**Central Repository**

- 오픈 소스 라이브러리, 플러그인 등이 호스팅되는 저장소.
- Maven Repository Manager로 프라이빗하게 공유 가능.

**Remote Repository**

- 중앙 저장소 이외의 저장소.