# dart:async

<aside>
💡

Future, Stream, Zone 같은 비동기 프로그래밍을 위한 기능 패키지.

</aside>