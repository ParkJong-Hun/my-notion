# WeakReference

<aside>
💡

Garbage Collector가 강한 참조가 없을 경우 메모리를 비움.

</aside>