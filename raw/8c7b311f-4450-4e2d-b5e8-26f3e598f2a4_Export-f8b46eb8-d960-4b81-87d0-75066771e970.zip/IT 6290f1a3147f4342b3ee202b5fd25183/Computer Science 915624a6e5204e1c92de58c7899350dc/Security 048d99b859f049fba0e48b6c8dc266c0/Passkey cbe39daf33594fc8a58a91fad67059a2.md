# Passkey

<aside>
💡 패스키.
FIDO 표준을 기반으로 패스워드를 대체하고 디바이스의 모든 곳에서 웹사이트와 앱에 더 빠르고 간편하고 안전하게 로그인할 수 있도록 함.
항상 강력하고 피싱에 강함.
물리적으로 가까운 곳에 있는 다른 디바이스에서도 작동.

</aside>

[FIDO](FIDO%20a12b9e77a48743eda2bccb962d8e8ea1.md)

[Passkey 통신](Passkey%20cbe39daf33594fc8a58a91fad67059a2/Passkey%20%E1%84%90%E1%85%A9%E1%86%BC%E1%84%89%E1%85%B5%E1%86%AB%20187f37315c448003b34af4aa45085b39.md)