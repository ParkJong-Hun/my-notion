# Version catalog

<aside>
💡 TOML(Tom’s Obvious, Minimal Language) 형식으로 작성된 버전 목록 파일.

</aside>