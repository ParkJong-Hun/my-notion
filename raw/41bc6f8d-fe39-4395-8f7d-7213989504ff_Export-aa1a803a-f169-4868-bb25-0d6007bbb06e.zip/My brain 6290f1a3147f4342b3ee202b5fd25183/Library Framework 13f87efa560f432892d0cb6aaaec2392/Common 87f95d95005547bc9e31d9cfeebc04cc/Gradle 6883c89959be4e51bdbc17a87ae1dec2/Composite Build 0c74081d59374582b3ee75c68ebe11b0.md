# Composite Build

<aside>
💡

복합 빌드.
다른 빌드를 포함하는 빌드.
Gradle 다중 프로젝트 빌드와 비슷하지만, 전체 빌드가 포함된다는 것이 다름.

</aside>