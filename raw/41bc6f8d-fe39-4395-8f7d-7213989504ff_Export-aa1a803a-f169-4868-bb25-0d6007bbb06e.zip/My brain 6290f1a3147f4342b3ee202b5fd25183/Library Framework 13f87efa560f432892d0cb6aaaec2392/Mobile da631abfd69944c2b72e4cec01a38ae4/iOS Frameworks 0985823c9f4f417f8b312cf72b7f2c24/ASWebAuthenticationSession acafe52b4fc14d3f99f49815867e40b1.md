# ASWebAuthenticationSession

<aside>
💡 iOS 12에서 소개된, 앱 내에서 안전하게 웹 기반 인증, 로그인을 처리하는 데 사용되는 프레임워크.

</aside>