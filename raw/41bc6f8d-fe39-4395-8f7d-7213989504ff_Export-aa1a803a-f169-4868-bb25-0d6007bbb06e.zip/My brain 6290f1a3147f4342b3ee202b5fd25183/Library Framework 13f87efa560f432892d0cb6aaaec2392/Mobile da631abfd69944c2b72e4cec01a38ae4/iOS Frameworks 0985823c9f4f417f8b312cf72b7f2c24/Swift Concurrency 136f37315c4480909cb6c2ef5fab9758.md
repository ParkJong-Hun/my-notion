# Swift Concurrency

<aside>
💡

동기 처리와 비동기 처리를 거의 같은 작성 방법으로 작성 가능하게 해주는 프레임워크.

</aside>