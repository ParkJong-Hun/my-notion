# SLI

<aside>
💡 Service level indicator.
서비스 수준 지표.
제공된 서비스의 척도.

</aside>