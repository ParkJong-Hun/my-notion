# Shared responsibility model

<aside>
💡 공유 책임 모델.
클라우드의 보안은 클라우드 제공업체와 고객 간 공동 책임.

</aside>