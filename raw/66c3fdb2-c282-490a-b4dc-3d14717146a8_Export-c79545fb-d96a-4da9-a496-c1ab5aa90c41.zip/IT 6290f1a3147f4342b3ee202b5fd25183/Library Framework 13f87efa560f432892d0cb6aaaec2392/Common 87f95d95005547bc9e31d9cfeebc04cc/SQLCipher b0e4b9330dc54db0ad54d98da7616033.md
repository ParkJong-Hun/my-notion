# SQLCipher

<aside>
💡 SQLite 데이터베이스를 암호화하는 데 사용되는 오픈 소스 라이브러리.
SQLite의 기능을 그대로 유지하면서 AES-256을 사용해 데이터를 암호화.

</aside>