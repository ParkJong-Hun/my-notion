# Database

<aside>
💡 데이터베이스.
일반적으로 테이블에 저장되고 컴퓨터 시스템에서 전자적으로 액세스되는 조직화된 데이터 셋.

</aside>

[ACID](Database%20e2f95d48da1a44488b20d5d2ac1bc308/ACID%2016ff37315c4480a6be0ff614cb3c534a.md)