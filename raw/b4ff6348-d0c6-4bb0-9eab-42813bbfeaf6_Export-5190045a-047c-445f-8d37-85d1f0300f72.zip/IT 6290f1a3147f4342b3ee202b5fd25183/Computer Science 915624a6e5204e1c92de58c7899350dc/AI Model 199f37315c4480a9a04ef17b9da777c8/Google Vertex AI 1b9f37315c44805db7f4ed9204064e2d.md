# Google Vertex AI

<aside>
💡

Google Cloud에서 제공하는 AI 플랫폼.
개발자와 데이터 과학자가 AI 모델을 보다 쉽게 구축, 관리할 수 있도록 돕는 도구.

</aside>