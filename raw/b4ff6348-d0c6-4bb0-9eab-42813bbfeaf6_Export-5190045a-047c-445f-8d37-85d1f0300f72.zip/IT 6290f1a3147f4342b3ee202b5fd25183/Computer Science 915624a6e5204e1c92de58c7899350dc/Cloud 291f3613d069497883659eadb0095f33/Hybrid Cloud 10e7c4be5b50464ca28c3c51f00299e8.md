# Hybrid Cloud

<aside>
💡 하이브리드 클라우드.
애플리케이션이 다양한 환경의 조합에서 실행됨.

</aside>