# Stakeholder

<aside>
💡

어떤 조직이나 프로젝트, 결정 등과 관련되어 있는 이해관계자.

</aside>