# JVM Toolchain

<aside>
💡

JVM을 기반으로 한 앱을 개발, 빌드, 실행, 디버깅, 테스트, 모니터링하기 위한 도구와 환경의 집합.

</aside>