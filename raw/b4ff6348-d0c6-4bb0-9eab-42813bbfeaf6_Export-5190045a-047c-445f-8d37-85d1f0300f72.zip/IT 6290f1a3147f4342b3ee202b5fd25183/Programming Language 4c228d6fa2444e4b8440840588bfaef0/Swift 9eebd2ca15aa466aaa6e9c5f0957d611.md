# Swift

<aside>
💡 주로 Apple의 앱을 만드는데 사용되는 Objective-C의 대안 현대적인 함수형 언어.
LLVM 컴파일러를 사용해 LLVM 바이트 코드로 변환된다.

</aside>

[Bridging-Header.h](Swift%209eebd2ca15aa466aaa6e9c5f0957d611/Bridging-Header%20h%20139f37315c4480829398e255f6c8609a.md)

[NS](Swift%209eebd2ca15aa466aaa6e9c5f0957d611/NS%20139f37315c448079bb21c45d5f472181.md)

### 비동기 처리

- **async await**

async 함수를 정의 후 await으로 해당 비동기 함수를 호출하면, async 함수가 끝날 때까지 기다림.

- **Task**

비동기 블록. 비동기 작업을 병렬로 실행하거나 여러 작업을 기다릴 때 사용.

### 확장

- **extension**

### 타입 메소드

생성자를 통해서 인스턴스를 생성하지 않아도 접근 가능한 메소드.

- class func
    - override 가능
- static func
    - override 불가능 (final class와 유사)

### 타입 프로퍼티

생성자를 통해서 인스턴스를 생성하지 않아도 접근 가능한 프로퍼티.

class 타입 프로퍼티는 연산 타입 프로퍼티로 표현해야 함.

- mutating

Value type(구조체, 열거형)의 프로퍼티를 수정할 수 있음을 의미.

self로 인스턴스 자체를 재할당 가능.

### 참조

메모리가 참조되고 해제될 때 ARC가 자동으로 관리함.

- strong

강한 참조.  상호 참조하는 경우 강한 순환 참조가 만들어질 수 있어서 메모리 누수가 발생할 수 있음.

- weak

약한 참조. 강한 순환 참조를 해결할 수 있음. 변수의 메모리가 해제되면 강한 참조와 달리 객체의 메모리까지 해제.

- unowned

미소유  참조. 다른 인스턴스와 같은 생명주기를 가지거나 더 긴 생명주기를 가질 때 사용. Optional에 사용 불가능.