# Gradle Plugin

<aside>
💡 build.gradle에 추가적인 기능을 제공하는 확장 모듈.
특정 작업을 자동화하거나 특정 프로젝트에 맞게 Gradle 빌드를 구성하는 데 사용.

</aside>