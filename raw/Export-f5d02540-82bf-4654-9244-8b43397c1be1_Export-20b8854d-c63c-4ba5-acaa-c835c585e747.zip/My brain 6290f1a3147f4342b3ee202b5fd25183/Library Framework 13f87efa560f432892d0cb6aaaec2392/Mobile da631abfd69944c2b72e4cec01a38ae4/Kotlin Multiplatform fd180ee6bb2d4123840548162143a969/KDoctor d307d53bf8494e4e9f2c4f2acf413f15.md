# KDoctor

<aside>
💡 Kotlin Multiplatform을 사용할 수 있는 환경인지 진단.

</aside>