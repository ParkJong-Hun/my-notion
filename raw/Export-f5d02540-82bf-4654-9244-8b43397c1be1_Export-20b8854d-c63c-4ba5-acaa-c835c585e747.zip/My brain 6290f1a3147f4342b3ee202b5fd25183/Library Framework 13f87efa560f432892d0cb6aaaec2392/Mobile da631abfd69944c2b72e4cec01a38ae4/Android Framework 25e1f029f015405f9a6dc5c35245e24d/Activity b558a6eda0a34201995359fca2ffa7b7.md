# Activity

<aside>
💡 유저가 앱과 상호작용하는 하나의 화면을 의미.

</aside>