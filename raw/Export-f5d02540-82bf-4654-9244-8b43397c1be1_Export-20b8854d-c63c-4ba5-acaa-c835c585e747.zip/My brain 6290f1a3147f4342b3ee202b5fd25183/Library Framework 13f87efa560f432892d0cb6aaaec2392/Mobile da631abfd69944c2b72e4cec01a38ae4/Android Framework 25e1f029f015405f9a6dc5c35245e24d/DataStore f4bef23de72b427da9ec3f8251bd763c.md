# DataStore

<aside>
💡 스레드에 안전한 안드로이드의 영구 데이터 저장 솔루션.
기본적으로 저장과 취득을 Flow로 관리함.

</aside>