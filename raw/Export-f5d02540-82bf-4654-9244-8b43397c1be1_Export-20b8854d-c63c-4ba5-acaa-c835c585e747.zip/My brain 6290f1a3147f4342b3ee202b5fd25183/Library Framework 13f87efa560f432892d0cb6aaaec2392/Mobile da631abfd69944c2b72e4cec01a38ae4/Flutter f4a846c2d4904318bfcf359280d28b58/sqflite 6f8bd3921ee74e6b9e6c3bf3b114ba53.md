# sqflite

<aside>
💡 SQLite에 데이터를 저장하기 위해 사용하는 패키지.

</aside>