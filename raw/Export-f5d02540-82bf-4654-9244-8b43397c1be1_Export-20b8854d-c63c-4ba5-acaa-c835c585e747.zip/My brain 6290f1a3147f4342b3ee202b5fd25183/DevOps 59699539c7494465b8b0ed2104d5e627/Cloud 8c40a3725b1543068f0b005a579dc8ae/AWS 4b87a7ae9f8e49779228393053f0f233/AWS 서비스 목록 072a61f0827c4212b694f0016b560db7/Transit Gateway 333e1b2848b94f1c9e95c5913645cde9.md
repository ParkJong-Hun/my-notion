# Transit Gateway

<aside>
💡 VPC, 계정 연결을 쉽게 확장.

단일 게이트웨이에 연결할 수 있도록 지원.

</aside>