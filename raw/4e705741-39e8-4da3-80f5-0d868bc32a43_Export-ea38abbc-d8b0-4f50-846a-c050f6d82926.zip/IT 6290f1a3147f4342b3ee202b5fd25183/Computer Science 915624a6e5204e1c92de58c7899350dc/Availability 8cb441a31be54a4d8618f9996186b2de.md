# Availability

<aside>
💡 가용성.
데이터에 대한 무단 액세스를 방지하면서도 필요할 때 데이터를 사용할 수 있음.

</aside>