# Digital Signature

<aside>
💡

일반적으로 CA에서 제공하는 데이터의 무결성과 인증을 보장하기 위한 암호화 기술.

</aside>