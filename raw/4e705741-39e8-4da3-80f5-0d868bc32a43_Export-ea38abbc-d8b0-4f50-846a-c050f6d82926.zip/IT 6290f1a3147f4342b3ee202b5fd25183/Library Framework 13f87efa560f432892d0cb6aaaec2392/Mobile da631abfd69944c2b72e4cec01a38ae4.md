# Mobile

## 네이티브

[Android Framework](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Android%20Framework%2025e1f029f015405f9a6dc5c35245e24d.md)

[Cocoa Touch](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Cocoa%20Touch%200985823c9f4f417f8b312cf72b7f2c24.md)

## 크로스 플랫폼

[Xamarin](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Xamarin%20153f37315c44804dad54ee7e6f35a5ac.md)

[Apache Cordova](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Apache%20Cordova%20153f37315c448018a5a3d710f510c98c.md)

[Flutter](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Flutter%20f4a846c2d4904318bfcf359280d28b58.md)

[React Native](Mobile%20da631abfd69944c2b72e4cec01a38ae4/React%20Native%20288d8f12c76b49db94d4f77d5daba56b.md)

[Kotlin Multiplatform](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Kotlin%20Multiplatform%20fd180ee6bb2d4123840548162143a969.md)

## 클라이언트 비동기 프레임워크

[Room](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Room%20c718f0c8aca646079170f7dd14841be6.md)

[Realm](Mobile%20da631abfd69944c2b72e4cec01a38ae4/Realm%20911421467b114a8f82f5a9429d3e0a4a.md)