# Google Maven Repository

<aside>
💡 Android 개발을 위한 공식적인 Maven 저장소.
Android Support 라이브러리, Google Play 서비스 라이브러리 등을 포함한 Android 프레임워크의 종속성가 Maven에 공개되어 있음.

</aside>