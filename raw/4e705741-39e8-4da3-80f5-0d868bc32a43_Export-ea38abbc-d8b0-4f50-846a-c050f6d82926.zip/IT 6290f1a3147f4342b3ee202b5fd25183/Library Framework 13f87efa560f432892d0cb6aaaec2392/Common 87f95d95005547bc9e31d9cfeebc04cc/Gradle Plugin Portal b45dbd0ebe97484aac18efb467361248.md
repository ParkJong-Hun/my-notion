# Gradle Plugin Portal

<aside>
💡 Gradle 플러그인을 호스팅하고 공유할 수 있는 공식적인 저장소.

</aside>