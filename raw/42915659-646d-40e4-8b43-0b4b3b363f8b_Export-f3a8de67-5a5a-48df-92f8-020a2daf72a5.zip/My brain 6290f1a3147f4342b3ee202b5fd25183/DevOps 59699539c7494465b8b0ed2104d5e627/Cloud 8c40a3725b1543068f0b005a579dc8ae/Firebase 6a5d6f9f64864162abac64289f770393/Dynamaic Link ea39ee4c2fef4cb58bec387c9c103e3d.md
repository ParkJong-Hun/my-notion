# Dynamaic Link

<aside>
💡 Firebase에서 플랫폼에 관계없이 제공하는 딥 링크.

</aside>

[Deep Link](../../../Computer%20Science%20915624a6e5204e1c92de58c7899350dc/Deep%20Link%20fab576d7837c4034a7b0a93c1bebf099.md)