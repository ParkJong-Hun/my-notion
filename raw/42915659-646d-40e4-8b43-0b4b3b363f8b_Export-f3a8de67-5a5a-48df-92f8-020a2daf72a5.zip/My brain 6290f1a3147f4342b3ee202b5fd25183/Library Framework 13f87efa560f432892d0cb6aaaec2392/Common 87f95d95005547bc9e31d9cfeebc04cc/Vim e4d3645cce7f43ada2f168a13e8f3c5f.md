# Vim

<aside>
💡 Unix, Linux 환경에서 사용되는 텍스트 편집기인 Vi의 업그레이드 버전.

</aside>