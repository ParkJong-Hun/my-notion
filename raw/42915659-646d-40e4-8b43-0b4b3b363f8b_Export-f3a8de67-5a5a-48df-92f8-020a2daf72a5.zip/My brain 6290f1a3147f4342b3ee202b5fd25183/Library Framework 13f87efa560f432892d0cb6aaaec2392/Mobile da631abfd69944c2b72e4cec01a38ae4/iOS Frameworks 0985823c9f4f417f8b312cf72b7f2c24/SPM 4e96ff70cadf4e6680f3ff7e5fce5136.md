# SPM

<aside>
💡 Swift Package Manager.
Swift 패키지 관리를 위한 공식 도구.
기본적으로는 Swift에 특화.
의존성을 재귀적으로 해결하고 자동적으로 해결.
XCode Project 파일을 생성하지 않음.

</aside>