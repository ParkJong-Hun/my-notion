# MetalPetal

<aside>
💡 GPU 가속을 사용한 이미지, 비디오 처리 프레임워크.

</aside>