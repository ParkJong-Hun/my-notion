# InstrumentationTestRunner

<aside>
💡 Android의 통합 테스트를 실행하는 데 사용되는 테스트 러너.
앱과 상호작용 해 테스트를 실행하며, UI 테스트에 주로 사용됨.

</aside>