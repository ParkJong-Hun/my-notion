# FragmentManager

<aside>
💡 Fragment를 추가, 삭제, 교체, 백 스택 추가하는 등의 작업을 실행하는 클래스.
FragmentActivity, AppCompatActivity에서 `getSupportFragmentManager()` 로 취득 가능.

</aside>

[Fragment Transaction](FragmentManager%2073b56a7019a643f380ed00e0bb55033e/Fragment%20Transaction%200d68d75a8ef24dddb63bd0e073d44343.md)