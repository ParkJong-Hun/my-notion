# React Native

<aside>
💡 모바일 크로스 플랫폼 React Native

</aside>

**사용하는 프로그래밍 언어**

[Javascript](../../Script%20Language%20ae7db65ea7e343648a4540a0db8d25f3/Javascript%203b41518476b941a8bc1218bfaf523561.md)

[Typescript](../../Script%20Language%20ae7db65ea7e343648a4540a0db8d25f3/Typescript%20d2e37b14817649009ee3cd2c03cf9bf9.md)