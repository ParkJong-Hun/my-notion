# Rust

<aside>
💡

모질라 재단에서 개발한 저수준 시스템 프로그래밍 언어.
메모리 관리 안전성 강조.

</aside>

[Cargo](Rust%20f30cf984aa5e45a7bb0af1c41c4b2c16/Cargo%20125f37315c44800086a9c4fc48d7b453.md)

### Type

**u**

- unsigned integer.

**i**

- signed integer.
- 타입을 정의하지 않고 정수를 작성하면 기본적으로 i32.

**f**

- floating point.
- 웬만하면 계산 안정성을 위해 64가 좋음.

**&str**

- string slice(string literal).
- 문자열을 담는 불변형 타입.

<aside>
⚠️

char는 무조건 4bytes.
u8으로 캐스팅 가능.

숫자 뒤에 u8 등 타입을 기입하면 해당 타입으로 인식됨.

</aside>

### Keyword

**let**

- 런타임 변수 선언.
- 기본적으로 immutable.

**const**

- 컴파일 타임 상수 선언.

**static**

- 전역 변수 선언.

**mut**

- mutable variable.

**{}**

- display print.
- 문자열 안에 다른 타입의 값을 넣을 때.

**fn name(paramters) → returnType { code }**

- function.
- 내부 코드는 return이 없으면 마지막 작성한 내용이 return.

**()**

- empty tuple.
- unit type(void).

**{:?}**

- debug print.
- 문자열 안에 다른 타입의 type 이름이나 프로퍼티.

**unsafe**

- 플랫폼 의존적 코드나 메모리에 직접 접근 하는 코드의 wrapper.
- 생 포인터에 역참조.
- unsafe 함수, 메소드 호출.
- mutable static에 접근, 수정.