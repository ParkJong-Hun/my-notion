# 행위 주도 개발 (BDD)

<aside>
💡 Behavior Driven Development.
사용자의 행위까지 생각하고 테스트하며 개발. 
TDD의 한 종류로, 프론트엔드에서 조금 더 장점이 두드러지는 경향이 있음. 
메소드 위주의 TDD보다 행동을 조금 더 강조.

</aside>