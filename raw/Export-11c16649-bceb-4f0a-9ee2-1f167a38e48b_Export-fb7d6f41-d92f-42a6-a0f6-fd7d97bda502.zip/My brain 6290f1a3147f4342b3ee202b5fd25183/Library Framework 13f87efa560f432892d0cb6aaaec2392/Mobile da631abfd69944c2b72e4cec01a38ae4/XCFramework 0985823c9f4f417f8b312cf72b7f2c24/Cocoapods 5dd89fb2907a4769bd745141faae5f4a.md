# Cocoapods

<aside>
💡 iOS 및 macOS 애플리케이션 개발을 위한 라이브러리 관리 도구

</aside>

[CocoaPods 커맨드](Cocoapods%205dd89fb2907a4769bd745141faae5f4a/CocoaPods%20%E1%84%8F%E1%85%A5%E1%84%86%E1%85%A2%E1%86%AB%E1%84%83%E1%85%B3%2034e1130a86264bef89f610252952e863.md)

[Podspec](Cocoapods%205dd89fb2907a4769bd745141faae5f4a/Podspec%200adf4cfcfe234c04950dfdc751406368.md)