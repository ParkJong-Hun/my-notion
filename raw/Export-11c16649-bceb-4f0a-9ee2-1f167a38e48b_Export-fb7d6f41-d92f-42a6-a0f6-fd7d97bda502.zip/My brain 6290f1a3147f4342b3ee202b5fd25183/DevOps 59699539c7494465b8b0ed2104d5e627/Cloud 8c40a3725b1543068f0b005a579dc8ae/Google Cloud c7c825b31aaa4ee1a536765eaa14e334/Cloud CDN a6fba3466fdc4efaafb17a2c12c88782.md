# Cloud CDN

<aside>
💡 웹, 동영상 전송을 위한 콘텐츠 전송 네트워크.

</aside>