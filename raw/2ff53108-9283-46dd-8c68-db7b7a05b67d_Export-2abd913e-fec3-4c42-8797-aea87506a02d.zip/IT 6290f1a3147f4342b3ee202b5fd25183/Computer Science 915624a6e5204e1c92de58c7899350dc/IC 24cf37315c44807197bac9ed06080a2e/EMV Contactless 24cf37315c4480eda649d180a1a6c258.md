# EMV Contactless

<aside>
💡

= NFC.
카드를 대면 무선으로 전원 공급.
106~424 kpbs로 0.1~0.5초 걸림.

</aside>