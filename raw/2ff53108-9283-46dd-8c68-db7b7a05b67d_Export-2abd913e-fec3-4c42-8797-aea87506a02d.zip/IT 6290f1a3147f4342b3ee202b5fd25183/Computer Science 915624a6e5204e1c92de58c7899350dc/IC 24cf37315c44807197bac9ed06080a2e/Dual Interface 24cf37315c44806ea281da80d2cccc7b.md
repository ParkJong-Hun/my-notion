# Dual Interface

<aside>
💡

꽂아도 되고, 대도 됨.

</aside>