# Page

<aside>
💡

가상 메모리를 일정한 크기로 나눈 블록.

</aside>