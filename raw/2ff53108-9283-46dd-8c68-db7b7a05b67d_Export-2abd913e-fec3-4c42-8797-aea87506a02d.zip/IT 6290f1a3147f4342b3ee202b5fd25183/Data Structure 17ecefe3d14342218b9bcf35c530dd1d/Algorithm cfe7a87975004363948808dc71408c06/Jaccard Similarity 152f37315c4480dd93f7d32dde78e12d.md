# Jaccard Similarity

<aside>
💡

Jaccard 유사도.
집합 간 유사도를 계산.
두 집합의 교집합 크기를 합집합 크기로 나누어 계산.
텍스트 분석에서 단어 집합 간 유사도를 비교할 때 사용.

</aside>