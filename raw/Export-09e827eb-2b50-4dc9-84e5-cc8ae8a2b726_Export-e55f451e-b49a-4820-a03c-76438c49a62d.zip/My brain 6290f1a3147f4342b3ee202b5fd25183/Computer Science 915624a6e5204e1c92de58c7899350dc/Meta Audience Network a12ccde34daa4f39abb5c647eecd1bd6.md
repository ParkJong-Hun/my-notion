# Meta Audience Network

<aside>
💡 Facebook의 광고 네트워크로 Google AdMob보다 수수료가 저렴하고 대형 퍼블리셔를 통해 광고 게재 가능.
플랫폼의 의존도가 매우 높음.

</aside>