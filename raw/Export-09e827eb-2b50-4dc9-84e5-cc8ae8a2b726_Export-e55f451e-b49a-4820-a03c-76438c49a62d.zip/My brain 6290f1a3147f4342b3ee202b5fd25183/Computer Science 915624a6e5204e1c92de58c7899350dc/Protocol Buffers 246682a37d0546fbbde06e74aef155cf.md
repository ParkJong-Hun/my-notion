# Protocol Buffers

<aside>
💡 proto-buf.
여러 데이터를 간단하게 직렬화.

</aside>