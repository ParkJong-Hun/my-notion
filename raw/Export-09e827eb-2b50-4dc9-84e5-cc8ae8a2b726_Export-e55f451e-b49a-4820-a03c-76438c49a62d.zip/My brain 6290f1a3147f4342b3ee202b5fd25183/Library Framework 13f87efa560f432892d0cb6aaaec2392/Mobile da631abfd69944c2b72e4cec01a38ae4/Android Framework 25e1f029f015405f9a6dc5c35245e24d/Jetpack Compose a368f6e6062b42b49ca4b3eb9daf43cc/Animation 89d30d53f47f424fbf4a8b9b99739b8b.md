# Animation

**AnimatedVisibility**

- 표시하거나 숨길 때 나타남, 사라짐 애니메이션

**AnimatedContent**

- 다른 컴포저블 간에 애니메이션을 적용

**animateContentSize()**

- 자동 크기 변경 애니메이션

**animateHogeAsState**

- 단일 값을 애니메이션 처리하는 가장 간단한 방법

**Transition**

- 한 번에 여러 값에 애니메이션 적용

**InfiniteTransition**

- 지속적으로 애니메이션 적용

**AnimatedImageVector**

- 드로어블 파일을 로드하는 등으로 만드는 움직이는 이미지 벡터

**AnimationSpec**

- 애니메이션 사양(물리학 설정 등)