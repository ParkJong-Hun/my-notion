# Back Stack

<aside>
💡 Task 내에서 액티비티의 순서를 관리하는 스택 데이터 구조.

</aside>