# flutter doctor

**flutter doctor -v**

플러터 버전, 플러터 SDK 저장 위치 등을 반환

**flutter doctor**

플러터 관련 프레임워크들의 상태를 체크.

Flutter SDK, Android Studio, XCode, Chrome, Simulator, Emulator, Cocoapods, Android SDK Command-line Tools 등 인스톨 필요.

**flutter doctor --android-licenses**

플러터 호환되는 안드로이드 프레임워크를 체크