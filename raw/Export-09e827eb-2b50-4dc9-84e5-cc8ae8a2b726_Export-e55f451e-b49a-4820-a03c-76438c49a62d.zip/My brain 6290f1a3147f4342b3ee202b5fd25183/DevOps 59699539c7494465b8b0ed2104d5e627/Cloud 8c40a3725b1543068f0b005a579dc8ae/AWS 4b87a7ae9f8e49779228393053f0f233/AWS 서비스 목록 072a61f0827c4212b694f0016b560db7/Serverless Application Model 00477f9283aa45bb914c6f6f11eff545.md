# Serverless Application Model

<aside>
💡 서버리스 앱을 간단하게 구현하기 위한 CLI, 오픈 소스 프레임 워크.
CloudFormation을 확장한 SAM 템플레이트를 작성하는 것으로 APIGateway나 Lambda, DynamoDB 등의 환경을 간이 구축 가능.

</aside>