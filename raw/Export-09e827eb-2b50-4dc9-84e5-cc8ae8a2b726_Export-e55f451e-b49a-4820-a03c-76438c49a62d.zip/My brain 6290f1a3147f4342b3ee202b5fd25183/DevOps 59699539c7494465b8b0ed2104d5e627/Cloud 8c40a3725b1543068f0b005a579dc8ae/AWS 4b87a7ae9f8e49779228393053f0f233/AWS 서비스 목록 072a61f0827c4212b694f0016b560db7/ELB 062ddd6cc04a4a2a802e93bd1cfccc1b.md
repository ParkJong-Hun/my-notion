# ELB

<aside>
💡 **Elastic Load Balancing.**
접속량이 많은 경우 L4 서비스 트래픽을 분산시킴.

들어오는 앱 트래픽을 여러 다른 서비스에 자동 분산.

</aside>