# Snowball

<aside>
💡 Import/Export를 통해 대량의 데이터를 AWS로 이전할 때 네트워크가 아닌, 스토리지에 저장해 물리적으로 전달해 업로드.

대량의 데이터를 AWS로 업로드할 때 유용.

</aside>