# Cloud Bigtable

<aside>
💡 전체 조직, 특정 프로젝트 혹은 개별 Bigtable 데이터베이스 인스턴스에 적용할 수 있는 역할 제공.

</aside>