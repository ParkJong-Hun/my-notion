# Hierarchical Finite State Machine

<aside>
💡

HFSM.
계층적 유한 상태 머신.
FSM을 개선한 것으로, 각각의 상태 전이 후 조건에 맞는 하위 상태를 선택하는 구조.

</aside>