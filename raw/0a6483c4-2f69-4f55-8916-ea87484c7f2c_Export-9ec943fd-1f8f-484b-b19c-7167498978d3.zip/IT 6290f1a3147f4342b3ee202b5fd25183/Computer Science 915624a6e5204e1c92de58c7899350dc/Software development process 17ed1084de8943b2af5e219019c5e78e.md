# Software development process

<aside>
💡 소프트웨어 개발 방법론.

</aside>

[폭포수 방법론 (Waterfall)](Software%20development%20process%2017ed1084de8943b2af5e219019c5e78e/%ED%8F%AD%ED%8F%AC%EC%88%98%20%EB%B0%A9%EB%B2%95%EB%A1%A0%20(Waterfall)%20e9e540b699d64b5eb8305ff12e3fc2b4.md)

[**애자일 방법론 (Agile)**](Software%20development%20process%2017ed1084de8943b2af5e219019c5e78e/%EC%95%A0%EC%9E%90%EC%9D%BC%20%EB%B0%A9%EB%B2%95%EB%A1%A0%20(Agile)%206e6aa397c59e44d1a4cb1c9fdb54dc6b.md)

[도메인 주도 설계(DDD)](Software%20development%20process%2017ed1084de8943b2af5e219019c5e78e/%EB%8F%84%EB%A9%94%EC%9D%B8%20%EC%A3%BC%EB%8F%84%20%EC%84%A4%EA%B3%84(DDD)%209529713945204e3497f2dab7f2762bf8.md)

[테스트 주도 개발(TDD)](Software%20development%20process%2017ed1084de8943b2af5e219019c5e78e/%ED%85%8C%EC%8A%A4%ED%8A%B8%20%EC%A3%BC%EB%8F%84%20%EA%B0%9C%EB%B0%9C(TDD)%204db9a74638b34929acbcf03804f5338b.md)

[행위 주도 개발 (BDD)](Software%20development%20process%2017ed1084de8943b2af5e219019c5e78e/%ED%96%89%EC%9C%84%20%EC%A3%BC%EB%8F%84%20%EA%B0%9C%EB%B0%9C%20(BDD)%20cb9f2af43c734e1f9371dd1f53debf1c.md)

[인수 테스트 주도 개발 (ATDD)](Software%20development%20process%2017ed1084de8943b2af5e219019c5e78e/%EC%9D%B8%EC%88%98%20%ED%85%8C%EC%8A%A4%ED%8A%B8%20%EC%A3%BC%EB%8F%84%20%EA%B0%9C%EB%B0%9C%20(ATDD)%20147f37315c448023b66ed576e8653750.md)