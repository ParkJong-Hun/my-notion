# Amper

<aside>
💡 Gradle 플러그인으로 구현되며 YAML 방식을 사용한 프로젝트 구성을 위한 도구.
Kotlin Multiplatform에서 각 플랫폼의 의존성을 관리하기 최적화되어 있음.

</aside>