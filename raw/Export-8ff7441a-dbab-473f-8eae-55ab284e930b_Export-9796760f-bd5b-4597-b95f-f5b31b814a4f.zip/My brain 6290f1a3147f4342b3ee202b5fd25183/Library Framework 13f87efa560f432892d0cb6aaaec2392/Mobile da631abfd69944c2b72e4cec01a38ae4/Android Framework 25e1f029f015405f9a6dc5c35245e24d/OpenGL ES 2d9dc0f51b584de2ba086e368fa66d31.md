# OpenGL ES

<aside>
💡 OpenGL for Embedded Systems.
모바일 기기에 최적화된 OpenGL 표준.
하드웨어 가속을 활용해 고성능의 2D/3D 그래픽 렌더링.
복잡한 벡터 그래픽, 3D 모델, 고품질 애니메이션 등을 구현하는 데 적합.

</aside>