# Standalone Gradle Plugin

<aside>
💡 플러그인 클래스들을 포함하는 JAR을 생산하는 자바 프로젝트인 독립형(Standalone) 프로젝트에서 사용하는 Gradle Plugin.
자바 Gradle Plugin 개발 Plugin을 사용하기 위한 플러그인을 패지킹하고 공급하는 가장 쉽고 추천되는 방법.
자동적으로 Java Plugin을 적용하고, gradleApi() API 구성에 대해 종속성을 추가하고, 결과 JAR 파일에 필요한 플러그인 설명자를 생성하고, 게시 시 사용할 플러그인 마커 아티팩트를 구성.

</aside>