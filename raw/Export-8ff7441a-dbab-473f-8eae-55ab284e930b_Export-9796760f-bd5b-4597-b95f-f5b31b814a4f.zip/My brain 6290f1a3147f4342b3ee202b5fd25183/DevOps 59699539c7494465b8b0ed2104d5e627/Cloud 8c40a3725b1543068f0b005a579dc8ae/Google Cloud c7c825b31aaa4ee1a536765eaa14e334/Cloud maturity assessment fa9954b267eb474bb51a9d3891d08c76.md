# Cloud maturity assessment

<aside>
💡 클라우도 성숙도 평가.
Google Cloud에서 인정한 클라우드 채택 주제와 관련해 조직이 현재 어디에 있는지 파악 가능.

</aside>