# Lightsail

<aside>
💡 주어진 리소스 옵션(Ubuntu, Node.js, Django...) 중 하나를 선태해 가상 서버를 구축.

가상 머신, SSD 기반 스토리지, 데이터 전송, DNS 관리, 정적 IP 등을 포함.

</aside>