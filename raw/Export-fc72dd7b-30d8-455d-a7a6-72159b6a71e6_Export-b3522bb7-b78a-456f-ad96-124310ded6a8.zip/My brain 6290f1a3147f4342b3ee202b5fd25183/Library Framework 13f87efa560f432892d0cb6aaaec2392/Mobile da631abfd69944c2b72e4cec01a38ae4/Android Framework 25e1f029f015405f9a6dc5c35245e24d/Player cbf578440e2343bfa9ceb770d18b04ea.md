# Player

<aside>
💡 안드로이드의 Media3에서 동영상 스트리밍을 위해 사용하는 인터페이스 단위.
기본적으로 이 것의 일반 구현인 ExoPlayer를 사용.

</aside>