# Test Doubles

<aside>
💡 테스트 시 실제 객체 대신 사용되는 객체들.
테스트를 더 격리시키고 의존성을 모의하는 데 사용.

</aside>