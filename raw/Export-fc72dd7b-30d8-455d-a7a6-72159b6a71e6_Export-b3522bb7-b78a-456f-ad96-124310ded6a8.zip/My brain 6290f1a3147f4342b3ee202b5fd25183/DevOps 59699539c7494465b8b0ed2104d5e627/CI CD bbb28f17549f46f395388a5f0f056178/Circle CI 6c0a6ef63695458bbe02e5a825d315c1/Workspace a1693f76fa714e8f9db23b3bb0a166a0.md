# Workspace

<aside>
💡 각 Workflow는 workspace가 1:1 대응됨.
Workflow가 진행될 때 데이터를 다운 스트림 Job에 송신하기 위해 사용.
각 Workflow 고유의 데이터나 다운 스트림 Job에 필요한 데이터를 전달하는 것이 가능.
복수 브랜치에서 Job을 실행하는 Workflow에서는 Workspace를 사용해 데이터를 공유할 필요가 있음.

</aside>