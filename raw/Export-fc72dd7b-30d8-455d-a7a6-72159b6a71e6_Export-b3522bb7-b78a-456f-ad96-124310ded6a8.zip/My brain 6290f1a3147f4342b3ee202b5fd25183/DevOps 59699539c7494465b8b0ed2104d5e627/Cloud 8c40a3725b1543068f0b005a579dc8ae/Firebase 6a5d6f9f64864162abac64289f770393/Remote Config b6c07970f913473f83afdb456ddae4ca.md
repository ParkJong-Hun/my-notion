# Remote Config

<aside>
💡 Firebase의 서비스 중 하나로, 앱의 기능과 모양을 실시간으로 업데이트할 수 있게 해주는 서비스.

</aside>