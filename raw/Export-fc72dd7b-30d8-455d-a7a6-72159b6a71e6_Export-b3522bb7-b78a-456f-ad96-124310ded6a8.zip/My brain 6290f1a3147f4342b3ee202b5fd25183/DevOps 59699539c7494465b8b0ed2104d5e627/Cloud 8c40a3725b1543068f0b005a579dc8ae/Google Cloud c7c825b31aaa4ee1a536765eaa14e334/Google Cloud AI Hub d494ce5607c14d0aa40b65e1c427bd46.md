# Google Cloud AI Hub

<aside>
💡 개발자와 데이터 사이언티스트가 프로젝트에 사용할 수 있는 플러그 앤 플레이 AI 구성 요소인 저장소를 호스트함.

</aside>