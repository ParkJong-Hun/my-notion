# Deep Link

<aside>
💡 딥 링크.
앱 내의 특정 화면 또는 기능으로 바로 이동시키는 링크.

</aside>

[App Link](../../Library%20Framework%2013f87efa560f432892d0cb6aaaec2392/Mobile%20da631abfd69944c2b72e4cec01a38ae4/Android%20Framework%2025e1f029f015405f9a6dc5c35245e24d/App%20Link%20680c492b4d614b9393f522db24d4bacd.md)

[Universal Link](../../Library%20Framework%2013f87efa560f432892d0cb6aaaec2392/Mobile%20da631abfd69944c2b72e4cec01a38ae4/Cocoa%20Touch%200985823c9f4f417f8b312cf72b7f2c24/Universal%20Link%20b3f89f2d45a049a2ae6dc7980aef990d.md)

[Dynamaic Link](../../DevOps%2059699539c7494465b8b0ed2104d5e627/Cloud%208c40a3725b1543068f0b005a579dc8ae/Firebase%206a5d6f9f64864162abac64289f770393/Dynamaic%20Link%20ea39ee4c2fef4cb58bec387c9c103e3d.md)