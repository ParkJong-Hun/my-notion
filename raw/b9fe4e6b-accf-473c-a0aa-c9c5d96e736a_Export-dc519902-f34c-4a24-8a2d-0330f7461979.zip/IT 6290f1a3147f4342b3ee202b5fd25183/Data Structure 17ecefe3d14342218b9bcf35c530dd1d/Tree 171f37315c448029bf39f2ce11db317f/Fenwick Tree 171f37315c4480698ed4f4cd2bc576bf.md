# Fenwick Tree

<aside>
💡

펜윅 트리.
Binary Indexed Tree(BIT)라고도 불림.
구간 합과 특정 인덱스 값 업데이트를 효율적으로 수행하기 위해 사용되는 자료 구조로, 트리 구조처럼 보이지만 사실상 배열 기반.

</aside>