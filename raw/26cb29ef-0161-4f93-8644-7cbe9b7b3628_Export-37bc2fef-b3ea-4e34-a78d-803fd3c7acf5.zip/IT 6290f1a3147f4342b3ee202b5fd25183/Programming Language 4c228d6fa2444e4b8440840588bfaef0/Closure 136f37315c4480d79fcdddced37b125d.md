# Closure

<aside>
💡

S식으로 불리는 괄호로 감싼 표현식을 나열하는 현대판 LISP.

</aside>