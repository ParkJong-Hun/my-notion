# Apache Cassandra

<aside>
💡

고성능 분산형 NoSQL DB 시스템.

</aside>