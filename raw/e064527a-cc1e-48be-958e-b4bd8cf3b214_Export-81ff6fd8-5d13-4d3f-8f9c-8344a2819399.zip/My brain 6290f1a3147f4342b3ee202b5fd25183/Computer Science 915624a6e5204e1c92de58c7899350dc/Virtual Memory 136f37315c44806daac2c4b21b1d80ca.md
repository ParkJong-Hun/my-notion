# Virtual Memory

<aside>
💡

가상 메모리.
물리 메모리를 추상화해서 프로세스들이 연속된 물리적 메모리를 사용하는것 처럼 하는 기술.

</aside>