# PERT Chart

<aside>
💡

Program Evaluation Review Technique Chart.
프로젝트 작업들 간 의존성과 소요 시간을 분석하는 데 사용하는 기법.

</aside>