# Fragmentation

<aside>
💡

단편화.
패킷에서 사용하지 않는 빈 공간이 있어서 실제 사용 가능한 공간보다 낭비하는 현상.

</aside>