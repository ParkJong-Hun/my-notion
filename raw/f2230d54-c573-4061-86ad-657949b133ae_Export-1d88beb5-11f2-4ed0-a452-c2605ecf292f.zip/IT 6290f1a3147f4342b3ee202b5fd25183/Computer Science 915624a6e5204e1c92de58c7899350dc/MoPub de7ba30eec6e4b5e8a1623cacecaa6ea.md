# MoPub

<aside>
💡 Twitter가 운영하던 광고 플랫폼으로 Google에 인수됨.
AdMob과 유사한 기능을 제공하며 다양한 광고 형식을 지원하고 수수료도 AdMob과 비슷.

</aside>