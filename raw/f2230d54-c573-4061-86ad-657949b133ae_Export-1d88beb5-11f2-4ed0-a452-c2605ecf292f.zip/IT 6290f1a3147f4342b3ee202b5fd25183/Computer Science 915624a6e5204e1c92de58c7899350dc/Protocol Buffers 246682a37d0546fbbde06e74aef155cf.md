# Protocol Buffers

<aside>
💡 proto-buf.
여러 데이터를 간단하게 직렬화하는 구글 서비스.
.proto 파일에 데이터 구조를 정의해, 이를 바탕으로 다양한 언어의 코드를 자동 생성.
JSON이나 XML과 달리 바이너리로 직렬화되어 크기가 작고 파싱이 빠름.

</aside>