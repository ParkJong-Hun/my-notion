# Concurrency vs Parallelism

<aside>
💡 동시성(병행성) vs 병렬성.

</aside>

**Concurrency**

- 논리적으로 병렬로 작업이 실행되는 것처럼 보이는 것

**Parallelism**

- 물리적으로 병렬로 작업이 실행되는 것