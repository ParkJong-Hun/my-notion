# Native Thread

<aside>
💡

aka Kernel Thread or OS Thread.
OS에서 직접 관리하는 멀티코어 지원 스레드.

</aside>