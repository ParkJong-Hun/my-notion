# Business Intelligence solution

<aside>
💡 대규모 통찰력의 형태로 데이터를 제공.

</aside>