# Open Standard

<aside>
💡 누구나 공개적으로 접근하고 사용할 수 있는 특정 사양을 따르는 소프트웨어.
ex) HTTP, XML

</aside>