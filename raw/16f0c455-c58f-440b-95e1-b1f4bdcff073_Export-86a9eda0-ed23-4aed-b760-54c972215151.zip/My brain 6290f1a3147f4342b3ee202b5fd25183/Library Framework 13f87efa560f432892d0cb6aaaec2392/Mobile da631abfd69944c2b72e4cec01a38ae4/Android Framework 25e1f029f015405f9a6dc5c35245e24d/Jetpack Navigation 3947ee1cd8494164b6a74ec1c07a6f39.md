# Jetpack Navigation

<aside>
💡 Android에서 Fragment의 이동을 관리하기 위해서 사용하는 라이브러리.
개발자를 대신해서 복잡한 FragmentManager를 관리해줌.

</aside>