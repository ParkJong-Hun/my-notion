# Data point

<aside>
💡 데이터를 사용하는 것을 의미.

</aside>