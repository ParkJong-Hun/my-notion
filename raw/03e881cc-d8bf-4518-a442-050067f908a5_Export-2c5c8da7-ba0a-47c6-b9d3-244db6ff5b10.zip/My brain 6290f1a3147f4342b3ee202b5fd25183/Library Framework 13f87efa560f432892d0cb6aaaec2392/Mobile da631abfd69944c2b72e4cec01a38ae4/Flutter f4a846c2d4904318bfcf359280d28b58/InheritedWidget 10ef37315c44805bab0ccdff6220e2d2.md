# InheritedWidget

<aside>
💡

Flutter의 상태를 위젯 트리의 하위 위젯에 효율적으로 전달하기 위한 위젯.

</aside>