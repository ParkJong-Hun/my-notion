# SFSafariViewController

<aside>
💡 iOS 앱 내에서 웹 컨텐츠를 불러오고 보여주는 데 사용.

</aside>