# ScyllaDB

<aside>
💡

Apache Cassandra의 오픈소스 대안.

</aside>