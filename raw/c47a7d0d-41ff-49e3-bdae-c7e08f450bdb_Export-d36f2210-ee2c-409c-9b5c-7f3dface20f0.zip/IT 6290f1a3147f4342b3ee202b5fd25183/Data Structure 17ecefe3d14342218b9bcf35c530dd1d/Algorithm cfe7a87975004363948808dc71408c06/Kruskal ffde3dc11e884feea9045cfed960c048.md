# Kruskal

<aside>
💡 최소 비용 신장 트리를 찾는 알고리즘 중 하나.

</aside>