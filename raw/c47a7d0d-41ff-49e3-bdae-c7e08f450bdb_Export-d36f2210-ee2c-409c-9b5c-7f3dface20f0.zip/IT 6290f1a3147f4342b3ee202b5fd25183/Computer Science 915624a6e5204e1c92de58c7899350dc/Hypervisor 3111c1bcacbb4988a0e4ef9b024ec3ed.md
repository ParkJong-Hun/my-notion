# Hypervisor

<aside>
💡 물리적 하드웨어 위에 위치해 여러 VM이 구축되는 소프트웨어 계층.

</aside>