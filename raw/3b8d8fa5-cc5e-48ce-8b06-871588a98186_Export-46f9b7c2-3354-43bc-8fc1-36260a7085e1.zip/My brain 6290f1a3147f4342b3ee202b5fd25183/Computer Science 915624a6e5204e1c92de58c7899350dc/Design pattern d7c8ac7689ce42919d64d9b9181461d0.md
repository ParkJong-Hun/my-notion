# Design pattern

<aside>
💡 디자인 패턴

</aside>

[Builder Pattern](Design%20pattern%20d7c8ac7689ce42919d64d9b9181461d0/Builder%20Pattern%20f869b7efc5504bae8a65e4dbf481dac0.md)

[Factory Pattern](Design%20pattern%20d7c8ac7689ce42919d64d9b9181461d0/Factory%20Pattern%206fbef682782c4eea9768a17ef4cfa150.md)

[Observer Pattern](Design%20pattern%20d7c8ac7689ce42919d64d9b9181461d0/Observer%20Pattern%200aea27eb758646ce8903ad6c2d5940f8.md)

[Repository Pattern](Design%20pattern%20d7c8ac7689ce42919d64d9b9181461d0/Repository%20Pattern%20d5da511290c64abab58bfc95aa6359b0.md)

[Delegate Pattern](Design%20pattern%20d7c8ac7689ce42919d64d9b9181461d0/Delegate%20Pattern%20126f37315c448053a9b4f72c546dfd03.md)