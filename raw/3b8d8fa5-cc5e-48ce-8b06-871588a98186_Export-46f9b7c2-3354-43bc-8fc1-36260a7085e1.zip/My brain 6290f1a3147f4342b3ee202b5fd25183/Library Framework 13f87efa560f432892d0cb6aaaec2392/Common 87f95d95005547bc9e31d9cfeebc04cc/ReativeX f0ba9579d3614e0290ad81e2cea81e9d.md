# ReativeX

<aside>
💡 다양한 프로그래밍 언어, 플랫폼에서 비동기, 이벤트 기반 프로그래밍을 위한 라이브러리와 프레임워크의 집합.

</aside>

[RxJava](ReativeX%20f0ba9579d3614e0290ad81e2cea81e9d/RxJava%20fc828316c72c4e01aa6c9da21c7d4a68.md)

[RxSwift](ReativeX%20f0ba9579d3614e0290ad81e2cea81e9d/RxSwift%208cbccbb2c31c4577bd9a8c4571c31e93.md)

[RxCocoa](ReativeX%20f0ba9579d3614e0290ad81e2cea81e9d/RxCocoa%205d9c3eb10e504c22b78ee5da4bac7a63.md)