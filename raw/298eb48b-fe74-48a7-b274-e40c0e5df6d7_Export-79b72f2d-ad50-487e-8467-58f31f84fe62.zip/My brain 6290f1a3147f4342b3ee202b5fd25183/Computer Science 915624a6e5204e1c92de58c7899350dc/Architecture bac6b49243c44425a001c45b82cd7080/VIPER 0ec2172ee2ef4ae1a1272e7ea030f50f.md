# VIPER

<aside>
💡

View, Interactor, Presenter, Entity, Router.
iOS의 표준 GUI 패턴.

</aside>