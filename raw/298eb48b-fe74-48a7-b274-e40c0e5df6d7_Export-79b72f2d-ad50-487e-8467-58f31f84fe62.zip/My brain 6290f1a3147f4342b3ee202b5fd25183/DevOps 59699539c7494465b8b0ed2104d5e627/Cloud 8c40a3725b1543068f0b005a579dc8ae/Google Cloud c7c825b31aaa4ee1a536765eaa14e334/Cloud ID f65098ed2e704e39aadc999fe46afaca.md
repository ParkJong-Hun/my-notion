# Cloud ID

<aside>
💡 조직이 데이터와 시스템 모두의 보안과 무결성을 유지하기 위해 리소스에 대한 액세스를 제어하고 관리하는 데 도움이 되는 Google Cloud 솔루션.

</aside>