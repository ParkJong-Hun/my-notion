# Gradle Directory

<aside>
💡

작업을 수행하고 관리하기 위해 나누는 단위.

</aside>

**Gradle User Home Directory**

- 전역 구성 속성, 초기화 스크립트, 캐시, 로그 파일이 저장.
- 환경 변수 설정.

**Project Root Directory**

- 프로젝트의 모든 소스 파일 포함.