# Recoil

<aside>
💡

Facebook에서 개발한 React 상태 관리 라이브러리.
필요한 부분만 리렌더링하도록 되어 있음.

</aside>