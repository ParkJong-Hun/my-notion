# Perfetto

<aside>
💡 Android 10 이상에서 사용할 수 있는 플랫폼 차원의 추적 도구.

</aside>