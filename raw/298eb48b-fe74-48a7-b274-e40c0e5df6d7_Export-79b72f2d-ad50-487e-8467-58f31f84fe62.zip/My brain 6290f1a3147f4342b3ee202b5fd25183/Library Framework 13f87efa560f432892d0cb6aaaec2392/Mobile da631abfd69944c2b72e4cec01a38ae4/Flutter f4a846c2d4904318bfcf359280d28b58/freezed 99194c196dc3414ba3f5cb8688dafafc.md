# freezed

**@freezed**

immutable 데이터 클래스를 정의.

Kotlin의 data class같은 것에서 지원하는 함수도 지원,