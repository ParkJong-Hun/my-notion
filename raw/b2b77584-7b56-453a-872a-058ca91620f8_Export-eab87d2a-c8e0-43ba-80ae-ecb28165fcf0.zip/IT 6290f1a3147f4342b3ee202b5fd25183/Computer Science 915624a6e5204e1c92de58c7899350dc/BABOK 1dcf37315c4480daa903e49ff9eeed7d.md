# BABOK

<aside>
💡

Business Analysis Body of Knowledge.
비즈니스 분석가의 표준 가이드북.
IIBA에서 관리.
요구사항 분석, 전략 분석, 요구사항 수명주기 관리, 평가 및 검증 등을 포함.

</aside>