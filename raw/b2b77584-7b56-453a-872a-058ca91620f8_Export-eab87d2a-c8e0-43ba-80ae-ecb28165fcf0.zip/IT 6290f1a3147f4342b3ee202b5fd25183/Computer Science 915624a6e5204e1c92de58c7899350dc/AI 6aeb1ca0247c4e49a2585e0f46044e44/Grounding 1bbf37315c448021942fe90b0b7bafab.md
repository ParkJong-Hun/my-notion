# Grounding

<aside>
💡

특정 지식이나 리소스에 접속하는 것.
이 것으로 인해 LLM이 생성하는 대답 내용으로 전문적이고 정확하게 됨.
사실과는 다른 내용이나 문맥과 무관계한 출력을 생성하는 문제(Hallucination)을 더욱 회피하기 위해 사용됨.

</aside>

[RAG](Grounding%201bbf37315c448021942fe90b0b7bafab/RAG%201bbf37315c448071a287cb938d04ca74.md)