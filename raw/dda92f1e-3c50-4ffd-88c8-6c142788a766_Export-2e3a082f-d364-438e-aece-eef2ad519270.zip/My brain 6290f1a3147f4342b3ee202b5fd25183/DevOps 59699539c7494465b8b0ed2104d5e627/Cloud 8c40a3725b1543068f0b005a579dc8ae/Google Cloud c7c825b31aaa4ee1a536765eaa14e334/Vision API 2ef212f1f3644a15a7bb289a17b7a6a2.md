# Vision API

<aside>
💡 Google 데이터를 사용해 이미지의 얼굴, 개체, 텍스트, 감정까지 자동으로 감지해 강력하고 사전 훈련된 기계 학습 모델 제공.

</aside>