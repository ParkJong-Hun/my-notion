# Bitmap

<aside>
💡 이미지를  표현하기 위해 사용되는 객체.
모든 이미지는 Bitmap 객체로 관리됨.

</aside>