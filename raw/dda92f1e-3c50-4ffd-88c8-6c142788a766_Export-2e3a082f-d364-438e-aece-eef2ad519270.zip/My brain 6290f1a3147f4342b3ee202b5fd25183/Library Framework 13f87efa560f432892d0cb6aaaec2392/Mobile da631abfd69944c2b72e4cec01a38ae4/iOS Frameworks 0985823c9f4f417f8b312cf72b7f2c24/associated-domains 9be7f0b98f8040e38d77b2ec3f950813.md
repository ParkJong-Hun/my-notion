# associated-domains

<aside>
💡 iOS 앱과 웹사이트 간 상호 작용을 허용하는 기능.
앱과 해당 도메인 간 특정 기능 및 데이터 공유를 할 수 있음.

</aside>

**Entitlements**

- iOS, macOS 앱의 보안, 기능을 제어하는데 사용되는 권한 세트. 필요한 권한을 부여하고 관리하는 데 도움 됨.