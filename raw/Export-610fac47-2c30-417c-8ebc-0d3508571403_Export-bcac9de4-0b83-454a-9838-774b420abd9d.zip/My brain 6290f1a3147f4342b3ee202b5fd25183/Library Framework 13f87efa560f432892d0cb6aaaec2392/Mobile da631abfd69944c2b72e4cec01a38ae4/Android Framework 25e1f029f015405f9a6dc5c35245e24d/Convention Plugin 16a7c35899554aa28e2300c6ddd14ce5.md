# Convention Plugin

<aside>
💡 프로젝트 고유의 Gradle Plugin을 작성해 각 모듈에서 사용하도록 한 것.

</aside>