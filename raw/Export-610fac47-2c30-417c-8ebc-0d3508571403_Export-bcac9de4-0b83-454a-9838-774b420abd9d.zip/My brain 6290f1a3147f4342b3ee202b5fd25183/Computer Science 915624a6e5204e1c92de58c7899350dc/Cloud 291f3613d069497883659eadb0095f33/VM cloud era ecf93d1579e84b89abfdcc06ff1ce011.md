# VM cloud era

<aside>
💡

</aside>