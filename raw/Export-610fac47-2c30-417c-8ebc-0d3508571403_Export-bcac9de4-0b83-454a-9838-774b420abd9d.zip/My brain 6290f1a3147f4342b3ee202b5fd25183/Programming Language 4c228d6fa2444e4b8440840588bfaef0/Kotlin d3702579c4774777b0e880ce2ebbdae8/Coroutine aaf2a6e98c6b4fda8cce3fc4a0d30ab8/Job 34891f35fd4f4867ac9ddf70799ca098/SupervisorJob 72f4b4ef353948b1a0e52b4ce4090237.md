# SupervisorJob

<aside>
💡 부모, 자식 코루틴의 취소가 영향을 미치지 않는 독립성을 갖는 Job.

</aside>