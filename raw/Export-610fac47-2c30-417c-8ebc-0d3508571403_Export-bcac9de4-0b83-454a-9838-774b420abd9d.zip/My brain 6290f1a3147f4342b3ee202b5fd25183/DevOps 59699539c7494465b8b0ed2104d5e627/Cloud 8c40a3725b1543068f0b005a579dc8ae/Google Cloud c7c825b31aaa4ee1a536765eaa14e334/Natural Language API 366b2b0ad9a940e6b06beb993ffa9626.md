# Natural Language API

<aside>
💡 Google 데이터를 사용해 감정과 텍스트의 감정과 텍스트의 구문 항목을 발견해 텍스트를 사전 정의된 카테고리로 분류.

</aside>