# Cloud Talent Solution

<aside>
💡 구직, 인재 확보 기능과 함께 AI를 사용.

</aside>