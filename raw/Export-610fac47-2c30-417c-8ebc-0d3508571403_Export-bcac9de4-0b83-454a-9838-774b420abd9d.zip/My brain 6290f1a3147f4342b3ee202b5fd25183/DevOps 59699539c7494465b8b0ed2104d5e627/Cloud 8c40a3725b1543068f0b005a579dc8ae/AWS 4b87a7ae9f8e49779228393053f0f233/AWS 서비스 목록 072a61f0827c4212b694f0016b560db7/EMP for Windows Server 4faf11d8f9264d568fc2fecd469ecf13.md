# EMP for Windows Server

<aside>
💡 서포트가 중단되어서 동작하지 않는 Windows 앱을 새로운 Windows Server로 마이그레이션하는 서비스.
EMP는 ‘End-of-Support Migration Program’의 약자.

</aside>