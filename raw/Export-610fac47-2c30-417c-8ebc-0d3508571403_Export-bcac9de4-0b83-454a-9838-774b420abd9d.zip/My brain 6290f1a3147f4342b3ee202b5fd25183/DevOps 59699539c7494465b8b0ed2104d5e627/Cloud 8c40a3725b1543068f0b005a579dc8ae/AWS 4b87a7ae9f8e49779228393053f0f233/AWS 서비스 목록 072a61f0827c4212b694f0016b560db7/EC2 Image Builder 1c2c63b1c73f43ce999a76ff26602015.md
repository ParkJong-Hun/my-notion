# EC2 Image Builder

<aside>
💡 EC2에서 동작하는 OS 업데이트를 최신화하는 서비스.

</aside>