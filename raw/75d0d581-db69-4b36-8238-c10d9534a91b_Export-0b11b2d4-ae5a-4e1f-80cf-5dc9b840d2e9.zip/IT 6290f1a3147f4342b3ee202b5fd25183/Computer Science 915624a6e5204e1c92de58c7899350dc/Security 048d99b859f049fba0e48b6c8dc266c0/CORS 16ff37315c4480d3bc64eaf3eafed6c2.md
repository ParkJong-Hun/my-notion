# CORS

<aside>
💡

Cross-Origin Resource Sharing.
웹 앱이 서로 다른 출처 간에 리소스를 요청할 때 이를 제어하는 메커니즘.

</aside>