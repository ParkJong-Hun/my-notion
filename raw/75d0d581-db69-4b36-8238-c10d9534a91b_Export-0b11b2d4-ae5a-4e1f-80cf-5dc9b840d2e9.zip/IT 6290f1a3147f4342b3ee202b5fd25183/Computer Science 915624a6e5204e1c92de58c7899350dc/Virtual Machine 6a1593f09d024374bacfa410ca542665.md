# Virtual Machine

<aside>
💡 가상 머신.
여러 시스템이 동일한 하드웨어에서 실행될 있도록 리소스 최적화 한 형태.
이렇게 실행된 시스템.

</aside>