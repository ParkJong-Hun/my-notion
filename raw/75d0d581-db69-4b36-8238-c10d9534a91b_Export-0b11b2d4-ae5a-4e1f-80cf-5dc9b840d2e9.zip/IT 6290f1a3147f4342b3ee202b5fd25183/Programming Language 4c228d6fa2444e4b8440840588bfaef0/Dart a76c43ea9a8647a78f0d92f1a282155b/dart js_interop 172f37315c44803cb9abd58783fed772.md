# dart:js_interop

<aside>
💡

JavaScript와의 호환성을 돕는 기능과 Sound 타입을 갖는 패키지.

</aside>