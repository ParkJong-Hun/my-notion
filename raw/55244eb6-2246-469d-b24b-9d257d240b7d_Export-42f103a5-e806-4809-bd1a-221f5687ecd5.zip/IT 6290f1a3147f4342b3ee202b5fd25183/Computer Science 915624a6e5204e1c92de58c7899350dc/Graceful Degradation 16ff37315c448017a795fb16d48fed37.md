# Graceful Degradation

<aside>
💡

우아한 저하.
일부 구성 요소나 기능이 마비되어도, 전체 시스템이 계속 작동하도록 설계되어야 한다는 설계 원칙.

</aside>