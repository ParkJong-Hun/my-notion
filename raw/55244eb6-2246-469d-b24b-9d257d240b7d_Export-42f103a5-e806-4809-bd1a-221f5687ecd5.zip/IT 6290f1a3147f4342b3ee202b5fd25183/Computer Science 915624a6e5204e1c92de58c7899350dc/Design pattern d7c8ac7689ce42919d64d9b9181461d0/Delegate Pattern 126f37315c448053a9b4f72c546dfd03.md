# Delegate Pattern

<aside>
💡

상속에 대한 대안으로 객체의 일부 기능을 가져와 재사용을 할 수 있도록 하는 패턴.

</aside>