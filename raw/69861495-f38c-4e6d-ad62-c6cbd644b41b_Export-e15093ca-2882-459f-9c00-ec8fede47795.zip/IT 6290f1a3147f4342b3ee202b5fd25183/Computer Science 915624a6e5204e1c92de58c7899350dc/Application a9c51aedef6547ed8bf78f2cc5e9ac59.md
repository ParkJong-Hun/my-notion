# Application

<aside>
💡 사용자가 작업을 수행하는 데 도움이 되는 컴퓨터 프로그램 또는 소프트웨어.

</aside>