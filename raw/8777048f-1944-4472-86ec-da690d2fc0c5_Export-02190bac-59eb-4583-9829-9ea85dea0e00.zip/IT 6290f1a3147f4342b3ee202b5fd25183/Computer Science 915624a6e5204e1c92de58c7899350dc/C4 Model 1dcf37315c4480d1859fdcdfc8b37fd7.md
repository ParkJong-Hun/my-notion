# C4 Model

<aside>
💡

Context, Container, Component, Code.
소프트웨어 아키텍처를 시각적으로 표현하는 계층적 모델.

</aside>

**Context Diagram**

- 누가 이 시스템을 사용?

**Container Diagram**

- 어떤 주요 구성요소가 있음?

**Component Diagram**

- 각 구성요소 안에는 어떤 내부 컴포넌트가 있음?

**Code Diagram**

- 실제 클래스/모듈 수준 설계