# Machine Learning Model

<aside>
💡

데이터에서 패턴을 학습해 예측을 수행하는 알고리즘(랜덤 포레스트, SVM, KNN 등 전통적인 알고리즘)을 사용한 AI 모델.

CPU로도 가능하며, 사람이 직접 특징을 선택.

</aside>