# License

<aside>
💡 라이센스.

</aside>

1. **Open Source License:**
    - **GNU GPL(GNU 일반 공중 사용 허가서)**: 소프트웨어의 자유로운 공개와 공유를 촉진하기 위해 사용. 소스 코드를 수정하거나 재배포 할 경우 동일한 GPL 라이센스 하에서 공개해야 함.
    - **MIT License**: 상대적으로 관대한 라이센스로, 소프트웨어를 수정하고 재배포 할 수 있으며, 저작권 및 보증 책임을 완화.
    - **Apache License**: 오픈 소스 프로젝트에 많이 사용되며, 상업적 사용을 허용하고 소스 코드 공개를 요구하지 않음.
    - **BSD License**: 상대적으로 자유로운 라이센스로, 상업적인 제품에도 사용할 수 있으며 소스 코드 공개 의무가 없음.
2. **Creative Commons Licenses:** 컨텐츠 크리에이터들이 작품의 공개, 수정, 재배포 등을 조절하는 데 사용. 다양한 서브 라이센스가 있으며, CC BY(저작자 표시) 라이센스는 다른 사람이 작품을 재사용할 때 원작자를 표시하도록 요구하고, CC BY-SA(저작자 표시 - 동일 조건 변경 허용) 라이센스는 수정된 작품도 동일한 라이센스 하에서 공개해야 함.
3. **Proprietary Licenses:** 상용 소프트웨어 라이센스. 소프트웨어나 콘텐츠를 상용 목적으로 사용하는 데 사용. 소스 코드나 작품의 수정 및 재배포를 제한할 수 있음.

MIT License == BSD License == Apache License > CC BY > GNU GPL > Proprietary Licenses

[Open Standard](License%20820d62a61b2144ad859ce270e3eeda4e/Open%20Standard%202e8aec7d569541afb4a01744e2626fcd.md)

[Open Source](License%20820d62a61b2144ad859ce270e3eeda4e/Open%20Source%20e592712bf23540388af36e6e4400cc80.md)