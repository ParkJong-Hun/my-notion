# Asymptotic Notation

<aside>
💡

점근 표기법.
시간 복잡도와 공간 복잡도를 분석할 때 사용.

</aside>

[Big-O](Asymptotic%20Notation%20171f37315c4480b6a353e3edfa25a709/Big-O%20171f37315c44803190a0e2df451fb794.md)

[Omega](Asymptotic%20Notation%20171f37315c4480b6a353e3edfa25a709/Omega%20171f37315c4480e59f6ac330a47c2f76.md)

[Theta](Asymptotic%20Notation%20171f37315c4480b6a353e3edfa25a709/Theta%20171f37315c4480ebba19c3c9beddbca1.md)