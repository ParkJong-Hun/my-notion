# Skeleton UI

<aside>
💡 어떠한 데이터가 로딩중일 때, 대신에 표시할 UI를 어떠한 UI로 대체해 잠시동안 표시하는 방법.

</aside>