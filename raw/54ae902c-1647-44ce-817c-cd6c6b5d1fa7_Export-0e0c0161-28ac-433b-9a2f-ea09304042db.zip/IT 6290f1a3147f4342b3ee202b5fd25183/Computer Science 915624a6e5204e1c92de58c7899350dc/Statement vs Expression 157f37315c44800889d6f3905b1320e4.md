# Statement vs Expression

<aside>
💡

문 vs 식.

</aside>

### 문

하나의 동작을 수행하는 코드 조각.

### 식

하나의 값을 반환하는 코드 조각.