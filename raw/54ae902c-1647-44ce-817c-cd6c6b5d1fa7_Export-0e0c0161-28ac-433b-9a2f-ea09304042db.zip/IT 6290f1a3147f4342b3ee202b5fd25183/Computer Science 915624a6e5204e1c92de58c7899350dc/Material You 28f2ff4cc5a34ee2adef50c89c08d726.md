# Material You

<aside>
💡 Google이 개발한 Material에서 개별 사용자에게 맞춤화된 경험을 제공하는 것.
사용자의 개인 설정, 취향, 기기 특성을 고려해 UI 제공.

</aside>