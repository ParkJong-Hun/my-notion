# Routing Table

<aside>
💡

라우터들을 이용해 목적지에 도달하기 위한 최선의 방법을 찾아내기 위한 이정표.

</aside>