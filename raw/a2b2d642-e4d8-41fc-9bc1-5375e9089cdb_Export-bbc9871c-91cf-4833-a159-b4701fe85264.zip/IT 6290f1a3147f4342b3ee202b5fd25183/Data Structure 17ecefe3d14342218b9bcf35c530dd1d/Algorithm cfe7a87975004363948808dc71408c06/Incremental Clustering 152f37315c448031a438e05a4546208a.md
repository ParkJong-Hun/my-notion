# Incremental Clustering

<aside>
💡

점진적 클러스터링.
기존 클러스터를 새로 추가된 상품에 맞춰 점진적으로 업데이트.

</aside>