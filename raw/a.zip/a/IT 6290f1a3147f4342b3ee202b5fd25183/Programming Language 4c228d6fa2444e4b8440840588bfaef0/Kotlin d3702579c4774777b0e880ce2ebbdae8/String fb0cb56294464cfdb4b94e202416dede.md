# String

<aside>
💡 문자열에 관한 문서

</aside>