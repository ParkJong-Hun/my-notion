# Python

[.venv](Python%2007a8f178ee564892bfdb547abf3d5de2/venv%20249f37315c4480ee8262fa13b46c19a6.md)