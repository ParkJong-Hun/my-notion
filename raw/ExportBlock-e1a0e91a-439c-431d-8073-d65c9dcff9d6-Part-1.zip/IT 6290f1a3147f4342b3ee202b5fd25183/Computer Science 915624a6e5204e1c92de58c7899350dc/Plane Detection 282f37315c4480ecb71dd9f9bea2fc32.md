# Plane Detection

<aside>
💡

평면 검출.

AR에서 장치가 카메라와 센서를 사용해 주변 환경에 존재하는 평평한 표면을 실시간으로 인식하고 추적하는 기술.

</aside>