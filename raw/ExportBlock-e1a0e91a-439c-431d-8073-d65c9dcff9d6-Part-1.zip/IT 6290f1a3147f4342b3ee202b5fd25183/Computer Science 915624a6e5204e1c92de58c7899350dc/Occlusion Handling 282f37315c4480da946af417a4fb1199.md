# Occlusion Handling

<aside>
💡

페색 처리.

깊이 추정에서 얻은 정보를 사용해 가상 객체와 현실 객체 간 가려짐 관계를 시각적으로 올바르게 처리하는 기술.

</aside>