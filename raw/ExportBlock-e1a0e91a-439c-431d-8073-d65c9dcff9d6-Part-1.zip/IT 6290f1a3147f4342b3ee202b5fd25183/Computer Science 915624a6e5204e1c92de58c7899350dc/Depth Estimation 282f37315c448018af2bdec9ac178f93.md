# Depth Estimation

<aside>
💡

깊이 추정.

카메라와 센서를 사용해 장치와 장면 속 모든 물체 간 거리를 측정하고 3차원 구조를 파악하는 기술.

</aside>