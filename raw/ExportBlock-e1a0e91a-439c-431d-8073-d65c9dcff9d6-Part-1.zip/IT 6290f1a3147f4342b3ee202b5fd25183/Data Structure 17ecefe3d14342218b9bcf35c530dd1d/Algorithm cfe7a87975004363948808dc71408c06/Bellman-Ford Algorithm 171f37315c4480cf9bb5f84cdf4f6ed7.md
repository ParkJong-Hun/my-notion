# Bellman-Ford Algorithm

<aside>
💡

단일 출발점 최단 경로 알고리즘으로, 하나의 출발점으로부터 모든 다른 정점까지의 최단 경로를 구함.

</aside>