# Storage Gateway

<aside>
💡 On-Premise에 있는 데이터를 클라우드로 옮기기 위한 게이트웨이 연결.

</aside>