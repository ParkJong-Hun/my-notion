# DocumentDB

<aside>
💡 MongoDB와 호환되는 문서형 DB를 설정, 운영할 수 있는 서비스.

</aside>