# Cloud Logging

<aside>
💡 로그 파일을 모니터링 하는 도구.

</aside>