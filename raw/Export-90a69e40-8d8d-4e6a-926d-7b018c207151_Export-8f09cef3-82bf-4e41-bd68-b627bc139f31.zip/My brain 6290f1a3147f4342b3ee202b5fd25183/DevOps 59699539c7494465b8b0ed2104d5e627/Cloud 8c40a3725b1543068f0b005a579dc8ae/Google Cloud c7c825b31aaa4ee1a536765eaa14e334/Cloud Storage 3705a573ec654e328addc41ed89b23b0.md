# Cloud Storage

<aside>
💡 안전하고 내구성과 확장성이 뛰어난 객체 스토리지.

</aside>