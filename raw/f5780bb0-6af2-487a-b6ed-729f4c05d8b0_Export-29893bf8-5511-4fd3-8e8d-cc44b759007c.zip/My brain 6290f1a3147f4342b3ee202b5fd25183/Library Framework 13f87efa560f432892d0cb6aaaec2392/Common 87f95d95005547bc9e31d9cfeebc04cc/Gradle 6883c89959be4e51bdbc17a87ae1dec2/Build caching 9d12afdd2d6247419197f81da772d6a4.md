# Build caching

<aside>
💡

이전 빌드 결과를 저장하고 필요할 때 복원.
중복된 작업과 시간 소모적이고 값비싼 프로세스를 실행하는 비용을 방지.

`--build-cache` .

</aside>