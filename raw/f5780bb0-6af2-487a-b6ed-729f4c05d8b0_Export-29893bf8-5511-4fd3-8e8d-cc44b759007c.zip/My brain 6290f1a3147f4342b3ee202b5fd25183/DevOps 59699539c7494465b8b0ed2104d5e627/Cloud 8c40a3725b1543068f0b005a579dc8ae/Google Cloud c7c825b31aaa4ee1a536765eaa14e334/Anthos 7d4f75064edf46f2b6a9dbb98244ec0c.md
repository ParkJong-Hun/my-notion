# Anthos

<aside>
💡 기존 앱을 현대화하고 새 앱을 빌드하기 위한 플랫폼.

</aside>