# Serverless Computing

<aside>
💡 필요에 따라 컴퓨팅 성능과 같은 리소스가 백그라운드에서 자동으로 프로비저닝된다는 뜻.
Function as a Service라고도 불림.

</aside>