# Gemfile

Ruby 프로젝트에서 필요한 종속성(의존성)을 정의하는 파일.

Gem이 포함됨.