# Generic

**refied**

런타임에 Generic의 classType을 알 수 있게 함.