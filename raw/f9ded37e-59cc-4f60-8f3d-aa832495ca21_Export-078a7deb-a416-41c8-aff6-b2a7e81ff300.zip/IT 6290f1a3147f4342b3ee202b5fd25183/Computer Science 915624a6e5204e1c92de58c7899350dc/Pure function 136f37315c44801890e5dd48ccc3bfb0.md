# Pure function

<aside>
💡

순수 함수.

참조 투명한 코드.

</aside>