# 행위 주도 개발 (BDD)

<aside>
💡 Behavior Driven Development.
사용자의 행위까지 생각하고 테스트하며 개발. 
TDD의 한 종류로, 프론트엔드에서 조금 더 장점이 두드러지는 경향이 있음. 
메소드 위주의 TDD보다 행동을 조금 더 강조.

</aside>

[Given-When-Then Pattern](%E1%84%92%E1%85%A2%E1%86%BC%E1%84%8B%E1%85%B1%20%E1%84%8C%E1%85%AE%E1%84%83%E1%85%A9%20%E1%84%80%E1%85%A2%E1%84%87%E1%85%A1%E1%86%AF%20(BDD)%20cb9f2af43c734e1f9371dd1f53debf1c/Given-When-Then%20Pattern%20147f37315c4480cfb0dadb49ec139c0a.md)

[Describe-Context-It Pattern](%E1%84%92%E1%85%A2%E1%86%BC%E1%84%8B%E1%85%B1%20%E1%84%8C%E1%85%AE%E1%84%83%E1%85%A9%20%E1%84%80%E1%85%A2%E1%84%87%E1%85%A1%E1%86%AF%20(BDD)%20cb9f2af43c734e1f9371dd1f53debf1c/Describe-Context-It%20Pattern%20147f37315c44807eade3cd9e55011f45.md)