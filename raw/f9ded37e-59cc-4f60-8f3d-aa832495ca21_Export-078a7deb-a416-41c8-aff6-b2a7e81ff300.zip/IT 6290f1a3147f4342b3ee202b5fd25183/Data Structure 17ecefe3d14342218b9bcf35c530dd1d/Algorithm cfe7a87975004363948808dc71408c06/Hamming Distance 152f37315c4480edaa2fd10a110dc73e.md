# Hamming Distance

<aside>
💡

두 문자열 간 차이를 게산하는 방법.
각 위치에서 문자가 다를 때마다 1을 더해 계산.
DNA 서열 분석, 이진 코드 비교 등에 사용.

</aside>