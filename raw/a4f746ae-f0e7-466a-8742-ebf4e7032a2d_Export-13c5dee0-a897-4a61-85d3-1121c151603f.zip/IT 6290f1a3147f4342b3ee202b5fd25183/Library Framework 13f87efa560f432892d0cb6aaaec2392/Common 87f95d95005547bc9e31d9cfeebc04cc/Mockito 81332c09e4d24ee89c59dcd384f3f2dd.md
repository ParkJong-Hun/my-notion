# Mockito

<aside>
💡 Java에서 가장 널리 사용되는 mocking 라이브러리.
테스트 중 객체들 간 상호작용을 모의하고 확인하는 데 도움을 줌.
Android 앱 테스트에서는 외부 소스나 의존성을 모의해야 할 때 많이 사용됨.

</aside>