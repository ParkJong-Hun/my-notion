# dart:math

<aside>
💡

랜덤 생성기 등 수학적인 것들과 관련된 패키지.

</aside>