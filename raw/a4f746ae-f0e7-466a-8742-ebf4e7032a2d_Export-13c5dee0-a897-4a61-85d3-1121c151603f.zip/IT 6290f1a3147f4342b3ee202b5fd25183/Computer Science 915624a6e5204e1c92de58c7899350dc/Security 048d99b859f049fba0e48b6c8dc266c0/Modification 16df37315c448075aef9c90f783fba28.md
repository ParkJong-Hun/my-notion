# Modification

<aside>
💡

수정, 변조.
전송된 데이터를 원래의 데이터가 아닌 내용으로 바꾸는 행위.

무결성 저해.

</aside>