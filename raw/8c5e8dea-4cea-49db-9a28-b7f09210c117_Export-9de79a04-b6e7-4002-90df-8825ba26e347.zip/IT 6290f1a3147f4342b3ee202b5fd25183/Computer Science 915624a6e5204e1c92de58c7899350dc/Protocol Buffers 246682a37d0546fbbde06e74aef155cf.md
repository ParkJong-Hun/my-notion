# Protocol Buffers

<aside>
💡 proto-buf.
여러 데이터를 간단하게 직렬화하는 구글 서비스.

</aside>