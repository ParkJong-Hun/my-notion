# Android vital

<aside>
💡 Android 지원 기기에서 Google Play 앱의 안전성, 성능을 개선하기 위해 사용하는 Google의 모니터링 도구.

</aside>