# Bare Metal

<aside>
💡 기존 워크로드를 클라우드로 쉽게 마이그레이션 할 수 있는 VM 기반 컴퓨팅 솔루션.

</aside>