# Vanilla

<aside>
💡 아무런 프레임워크도 사용하지 않고 작성

</aside>