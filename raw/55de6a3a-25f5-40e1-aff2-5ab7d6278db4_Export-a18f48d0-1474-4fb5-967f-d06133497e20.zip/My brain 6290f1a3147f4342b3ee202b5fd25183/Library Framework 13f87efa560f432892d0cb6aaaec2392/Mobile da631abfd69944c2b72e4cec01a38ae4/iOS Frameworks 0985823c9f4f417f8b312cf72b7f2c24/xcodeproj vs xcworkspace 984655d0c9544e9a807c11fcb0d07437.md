# xcodeproj vs xcworkspace

**XCode Project**

- 단일 프로젝트에 대한 모든 설정, 구성, 리소스, 소스 코드를 포함
- 주로 단일 앱이나 프레임워크를 관리하기 위해 사용

**XCode Workspace**

- 여러 XCode Project와 다른 파일들을 하나로 그룹화한 단위
- 여러 프로젝트 간 종속성 관리, 작업 조직화에 사용