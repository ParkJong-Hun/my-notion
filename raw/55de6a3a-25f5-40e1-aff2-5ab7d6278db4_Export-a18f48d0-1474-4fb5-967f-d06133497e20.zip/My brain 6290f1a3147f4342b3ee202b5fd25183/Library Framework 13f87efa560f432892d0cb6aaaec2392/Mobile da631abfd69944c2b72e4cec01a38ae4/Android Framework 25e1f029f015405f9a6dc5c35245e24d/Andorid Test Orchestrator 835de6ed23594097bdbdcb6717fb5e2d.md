# Andorid Test Orchestrator

<aside>
💡 Android 통합 테스트를 테스트 스위트로 실행해, 테스트 결과를 보고하는 데 도움을 주는 도구.
CI/CD 환경에서 유용하고, 테스트를 격리시켜 상호 영향을 최소화하는 데 사용.

</aside>