# WebAssembly

<aside>
💡 WASM.
네이티브에 가까운 성능으로 동작해 컴팩트한 바이너리 포맷을 제공하는 저수준 어셈블리 언어.
웹에서 JavaScript와 함께 실행되며 서로를 보완할 수 있도록 설계됨.

</aside>