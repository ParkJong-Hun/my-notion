# Context API

<aside>
💡

React 16.3 이후 추가된 기능.
기존 로컬 상태를 종속성 주입 형태로 변환해 이벤트 버스로 props drilling을 회피.
useState, useReducer와 함께 사용하는 편.
성능 이슈가 발생하는 편.

</aside>