# SharedPreferences

<aside>
💡 키-값 쌍으로 데이터를 영구적으로 저장하는 솔루션.

</aside>

<aside>
⚠️ 스레드에 안전하지 않으므로 동시성 문제를 해결하기 위해 여러 사항을 고려해야 함.

</aside>