# Common

**IDE**

[IntelliJ](Common%2087f95d95005547bc9e31d9cfeebc04cc/IntelliJ%209f2e4ffc51424ea986343610c30ddde7.md)

[Fleet](Common%2087f95d95005547bc9e31d9cfeebc04cc/Fleet%20fe15e8eb3eb04cee8fd7cfdd9684aaa3.md)

[Vim](Common%2087f95d95005547bc9e31d9cfeebc04cc/Vim%20e4d3645cce7f43ada2f168a13e8f3c5f.md)

**라이브러리 관리**

[Gradle](Common%2087f95d95005547bc9e31d9cfeebc04cc/Gradle%206883c89959be4e51bdbc17a87ae1dec2.md)

[Amper](Common%2087f95d95005547bc9e31d9cfeebc04cc/Amper%205d9fb4577e7e469ab20b6fbdc35f81e5.md)

**라이브러리**

[Mockito](Common%2087f95d95005547bc9e31d9cfeebc04cc/Mockito%2081332c09e4d24ee89c59dcd384f3f2dd.md)

[JaCoCo](Common%2087f95d95005547bc9e31d9cfeebc04cc/JaCoCo%204f5cb78de3884c1e856c91bde7c14fb7.md)

[Okio](Common%2087f95d95005547bc9e31d9cfeebc04cc/Okio%20c878d8b2427d46e68b68f84017baabe3.md)

[Realm](Common%2087f95d95005547bc9e31d9cfeebc04cc/Realm%200cb986089b974db2b88e7f213f4db368.md)

[SQLCipher](Common%2087f95d95005547bc9e31d9cfeebc04cc/SQLCipher%20b0e4b9330dc54db0ad54d98da7616033.md)

[Axios](Common%2087f95d95005547bc9e31d9cfeebc04cc/Axios%20a2541f250b06436c98eadc53f6590010.md)

[Tink](Common%2087f95d95005547bc9e31d9cfeebc04cc/Tink%20c1b8ec1be6fa487292f714c0e59b0bf8.md)

[Java.security](Common%2087f95d95005547bc9e31d9cfeebc04cc/Java%20security%206a39a7853c074b888f7fa2b06377a748.md)

[ReativeX](Common%2087f95d95005547bc9e31d9cfeebc04cc/ReativeX%20f0ba9579d3614e0290ad81e2cea81e9d.md)

[SQLDelight](Common%2087f95d95005547bc9e31d9cfeebc04cc/SQLDelight%2069d99481ba574b5f8e92edbdbef17868.md)

[Salesforce SDK](Common%2087f95d95005547bc9e31d9cfeebc04cc/Salesforce%20SDK%20ebcb2275bfa74f69bad3ae4f2307ae3a.md)

[Kluent](Common%2087f95d95005547bc9e31d9cfeebc04cc/Kluent%20bfb25ca4596e43588d8090f528a4ef6d.md)

[Skia](Common%2087f95d95005547bc9e31d9cfeebc04cc/Skia%205ea8b0748469419a96698cd1bddcb136.md)

[Metalava](Common%2087f95d95005547bc9e31d9cfeebc04cc/Metalava%200e316917f18c49758eaf1f196cbb93de.md)

[OpenGL](Common%2087f95d95005547bc9e31d9cfeebc04cc/OpenGL%20122f37315c448061af59f81cee71df17.md)

[Vulkan](Common%2087f95d95005547bc9e31d9cfeebc04cc/Vulkan%20122f37315c4480afa6f2e2e43606b468.md)

[Impeller](Common%2087f95d95005547bc9e31d9cfeebc04cc/Impeller%20122f37315c448020aa7cf8b8e181ff3f.md)

**버전 관리**

[Git](Common%2087f95d95005547bc9e31d9cfeebc04cc/Git%20f039925ad97849ee99b331923f54c644.md)

[Maven](Common%2087f95d95005547bc9e31d9cfeebc04cc/Maven%206c09152554c54ae38a2b63a49fc17d02.md)

**포럼**

[Youtrack](Common%2087f95d95005547bc9e31d9cfeebc04cc/Youtrack%2087ac7e31534d4c4c8a1d7759a9ca9603.md)

[Mockk](Common%2087f95d95005547bc9e31d9cfeebc04cc/Mockk%202afb3ba6c7f4480bb5be9018ed5687b4.md)

[Maven Repository](Common%2087f95d95005547bc9e31d9cfeebc04cc/Maven%20Repository%209e928c2970cf42919bee2a08b27c1591.md)

[Jitpack](Common%2087f95d95005547bc9e31d9cfeebc04cc/Jitpack%20cb9e0a0f556248fcb8419e4471179c81.md)

[**Google Maven Repository**](Common%2087f95d95005547bc9e31d9cfeebc04cc/Google%20Maven%20Repository%200cc90bf0a3f8453088047a0dd44b5079.md)

[**Gradle Plugin Portal**](Common%2087f95d95005547bc9e31d9cfeebc04cc/Gradle%20Plugin%20Portal%20b45dbd0ebe97484aac18efb467361248.md)

[Spotless](Common%2087f95d95005547bc9e31d9cfeebc04cc/Spotless%20f84842659ce141a8880acc2044d163e9.md)