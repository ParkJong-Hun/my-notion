# Describe-Context-It Pattern

**Describe**

- 테스트 대상 설명.

**Context**

- 테스트 대상이 놓인 상황 설명.

**It**

- 테스트 대상의 행동 설명.