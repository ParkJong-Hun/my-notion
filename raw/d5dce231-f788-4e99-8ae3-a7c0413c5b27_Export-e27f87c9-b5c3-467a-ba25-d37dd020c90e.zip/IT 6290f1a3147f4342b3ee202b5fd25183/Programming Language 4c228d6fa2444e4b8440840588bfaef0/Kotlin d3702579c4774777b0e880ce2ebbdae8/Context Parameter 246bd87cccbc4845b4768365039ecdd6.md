# Context Parameter

<aside>
💡 with 내의 변수를 호출하는 곳에서도 참조 가능한 기능.
대신 스코프가 제한됨.
(이전에는 Context Receiver)

</aside>