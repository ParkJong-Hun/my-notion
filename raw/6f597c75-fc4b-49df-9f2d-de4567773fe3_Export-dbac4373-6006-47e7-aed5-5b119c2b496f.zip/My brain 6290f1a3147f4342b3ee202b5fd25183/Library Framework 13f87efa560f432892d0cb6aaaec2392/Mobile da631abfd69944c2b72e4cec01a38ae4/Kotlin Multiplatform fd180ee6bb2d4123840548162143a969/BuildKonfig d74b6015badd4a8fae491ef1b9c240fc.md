# BuildKonfig

<aside>
💡 Kotlin Multiplatform용 BuildConfig.

</aside>