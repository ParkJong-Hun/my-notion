# Material

<aside>
💡 Material Design을 구현하기 위한 Android 플랫폼 지원 라이브러리.
Android View 시스템에서 사용할 수 있는 Material Design 구성 요소 제공.

</aside>

## 컴포넌트

[TabRow](Material%2009e6d53bf04346cd8aac22e41e61e3cb/TabRow%20b955b021e5f14d0faae63b1751de62b4.md)

[Tab](Material%2009e6d53bf04346cd8aac22e41e61e3cb/Tab%209388225da12c49d7b6ca9e7c56a8af49.md)

[HorizontalPager](Material%2009e6d53bf04346cd8aac22e41e61e3cb/HorizontalPager%20a3890126ccfb465da1e5843383a6d7ec.md)