# HorizontalPager

**state**

HorizontalPager의 상태를 나타냄. 변수로 선언되어 있어서, 페이지가 변경될 때마다 업데이트 됨.

**content**

각 페이지에 대한 UI를 생성하는 함수. pages 리스트는 각 페이지의 내용을 포함하고 있음.

pages[page].content를 통해 현재 페이지의 내용을 가져올 수 있음.