# Fragment Transaction

<aside>
💡 런타임 시 UI 응답으로 Fragment와 함께 작업을 추가하거나 삭제, 교체하는 등 기타 작업을 할 수 있는 FragmentManager에서 커밋하는 각 프로그먼트 변경사항 집합인 Transaction 내에서 실행할 작업을 지정 가능하게 하는 클래스로 FragmentManager에서 취득 가능.

</aside>