# VPC IP Address Manager

<aside>
💡 VPC의 IP 주소를 할당하거나 검사, 모니터링하기 위한 관리 서비스.

</aside>