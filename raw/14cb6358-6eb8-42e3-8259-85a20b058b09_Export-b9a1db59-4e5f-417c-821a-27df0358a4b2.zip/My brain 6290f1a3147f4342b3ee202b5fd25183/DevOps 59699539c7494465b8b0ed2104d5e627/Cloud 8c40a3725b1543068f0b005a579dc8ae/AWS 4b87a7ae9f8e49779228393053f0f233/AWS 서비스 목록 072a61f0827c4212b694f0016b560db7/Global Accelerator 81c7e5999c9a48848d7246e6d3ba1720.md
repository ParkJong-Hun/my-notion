# Global Accelerator

<aside>
💡 고속의 AWS 네트워크를 이용해 국제적인 ALB나 EC2에 액세스하기 위한 서비스.

</aside>