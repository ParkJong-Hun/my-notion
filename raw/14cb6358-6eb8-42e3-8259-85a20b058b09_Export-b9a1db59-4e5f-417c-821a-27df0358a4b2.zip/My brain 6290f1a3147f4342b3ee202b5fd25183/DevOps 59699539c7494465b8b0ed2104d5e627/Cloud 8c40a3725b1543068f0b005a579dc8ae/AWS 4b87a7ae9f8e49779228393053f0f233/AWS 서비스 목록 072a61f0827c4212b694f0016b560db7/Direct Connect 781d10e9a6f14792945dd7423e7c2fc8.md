# Direct Connect

<aside>
💡 On-Premise(사내 자체 보유 서버(전산실 서버 등))와 연결을 쉽게할 수 있는 클라우드 서비스.

낮은 지연시간으로 데이터 공유.

</aside>