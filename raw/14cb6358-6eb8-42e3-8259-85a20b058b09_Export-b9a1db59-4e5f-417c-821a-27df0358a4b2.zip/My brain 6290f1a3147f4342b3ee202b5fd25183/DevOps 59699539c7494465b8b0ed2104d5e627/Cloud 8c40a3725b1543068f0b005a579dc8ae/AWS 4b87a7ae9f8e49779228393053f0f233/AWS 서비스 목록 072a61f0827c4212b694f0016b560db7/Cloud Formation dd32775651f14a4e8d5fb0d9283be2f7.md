# Cloud Formation

<aside>
💡 AWS 생성, 배포 자동화 템플릿 서비스.

Architecture 구현 시 미리 만들어 놓은 템플릿(JSON 파일)을 이용해 생성하거나, 직접 템플릿을 작성해 관리 가능.

</aside>