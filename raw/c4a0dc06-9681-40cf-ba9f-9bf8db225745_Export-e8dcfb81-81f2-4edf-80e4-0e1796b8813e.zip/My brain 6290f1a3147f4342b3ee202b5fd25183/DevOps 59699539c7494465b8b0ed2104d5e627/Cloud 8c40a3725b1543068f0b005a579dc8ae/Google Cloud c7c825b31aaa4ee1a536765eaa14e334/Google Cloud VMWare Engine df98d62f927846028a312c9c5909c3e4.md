# Google Cloud VMWare Engine

<aside>
💡 가상 머신에서 실행할 수 있는 소프트웨어 유형.
VMware 플랫폼을 실행할 수 있게 해주는 완전 관리형 서비스.

</aside>