# Precompiled script plugin

<aside>
💡 독립형 프로젝트로 작성된 플러그인 외에도 Groovy 혹은 Kotlin DSL로 작성된 빌드 로직을 사전 컴파일된 스크립 플러그인으로 제공.
사전에 컴파일되므로 런타임 시 더 좋은 성능을 제공하므로 Standalone Gradle Plugin보다 성능이 중요한 프로젝트에서 고려할 만 함.

</aside>