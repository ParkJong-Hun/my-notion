# ANR

<aside>
💡 Application Not Responding.
Android 앱의 UI 스레드가 너무 오랫동안 차단되면 트리거되는 에러.

</aside>