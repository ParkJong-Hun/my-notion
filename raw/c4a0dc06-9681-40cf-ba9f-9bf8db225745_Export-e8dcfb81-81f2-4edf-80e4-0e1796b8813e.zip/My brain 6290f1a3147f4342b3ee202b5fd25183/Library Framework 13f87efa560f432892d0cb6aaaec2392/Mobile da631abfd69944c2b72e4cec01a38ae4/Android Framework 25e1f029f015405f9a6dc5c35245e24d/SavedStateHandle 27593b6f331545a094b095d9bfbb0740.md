# SavedStateHandle

ViewModel이 Configuration 변경(예: 회전) 또는 프로세스 종료/재시작 등과 같은 상황에서 상태를 보존하고 사용되는 데 사용되는 클래스. 

SavedStateHandle은 ViewModel의 상태를 저장하고 복원하는 데에 사용될 수 있으며, 보통 Bundle과 비슷한 방식으로 사용.